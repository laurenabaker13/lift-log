# Lift Log Friends release tasks

- [ ] **Mutual Friends and privacy controls** — Add a Friends experience where people can only follow people who approve them; there is no public-figure or unapproved-follow model. A user can choose whether friends see their account name or a display name. Activity sharing is private by default and can be enabled for accepted friends only. Friends must never see full exercise summaries, weights/reps for ordinary completed sets, workout notes, RPE, or plan details.

- [ ] **Private workout activity and encouragement** — When an athlete has opted into activity sharing, accepted friends can see only completed-workout cards and PR cards such as “New Back Squat PR: 135 lb.” Add preset reactions and short text comments. Comments must be short, removable by the commenter or activity owner, and limited to accepted friends. Provide a simple way to remove a friend.

- [ ] **Individual lift challenges** — Add private, accepted-friend lift challenges for estimated one-rep max Bench Press, Back Squat, and Deadlift. A challenge must require the invited friend’s acceptance, show only the two participants’ challenge scores from completed logs, and never require public activity sharing. Use a simple 30-day duration and support only preset rivalry notes: “Nice lift,” “Your turn,” and “Catching up.”

- [ ] **Low-effort mobile Friends flow** — Add a Friends destination to the athlete navigation, a focused friend profile, requests, challenges, and a feed using the existing Flow State visual system. Keep Coach workspace navigation focused on coaching. The social flow must be easy to use between sets and should not add public discovery, complex privacy choices, or noise.

- [ ] **Data safety and release validation** — Keep all social records scoped to the authenticated user and an accepted connection. Include social settings/data in export and clear them during account deletion. Add deterministic tests for relationship approval, access rules, reaction/comment limits, and challenge score logic; synchronize only additive database changes; complete TypeScript, lint, tests, route verification, and an independent read-only review.

## First-time app guide

- [x] **Interactive, low-effort first-use guide** — After a new user chooses Follow a workout plan or Just log today’s workout, keep the real app visible and guide them through Plans, Workouts, Progress, Friends, and Settings. Highlight each current app surface and require the real tap on each next highlighted navigation tab before advancing. Explain the relevant live control in ordinary language, without automatically entering data, creating a plan, or creating a workout during the walkthrough. Support Skip guide; finishing or skipping must continue into the chosen plan or fresh solo workout.

- [x] **Replayable guidance and safe routing** — Add a Settings entry to replay the interactive guide at any time. The guide must never create a workout before the user finishes or skips it, must safely default unknown replay parameters to Workouts, and must stay declared in the Web route manifest. Verify the actual coach-mark flow, navigation lock, completion state/cache, and route behavior.

## Tutorial, recommended loads, and planned-day status

- [x] **Hands-on plan and workout setup tutorial** — Extend the live coach-mark tutorial so it shows the actual plan upload surface for PDF/photo/screenshot imports, explains review-before-save, calls out how to add a workout day when building a plan, and walks a solo logger through Start a solo workout → Add exercise → selecting a lift/equipment. Do not automatically select a file, add an exercise, create a plan, or save any data; keep all steps skippable and route safely back into the tour.

- [x] **Explainable RPE and load recommendations** — Keep Epley 1RM, inverse 3RM, and percent-of-rep-max calculations mathematically correct. Use RPE only for progression guidance in v1. If a user completed 85 lb for 8 reps and the next plan asks for 8 reps, do not recommend a lower generic percentage-derived load: recommend 90 lb when the result was at or below target RPE, hold when it was one RPE point above target, and reduce by only one standard increment for a much harder/missed set. Use a conservative percentage-derived suggestion only without usable prior performance; never override a manual target/coach weight. Show a brief, understandable explanation next to the recommendation.

- [x] **Skip planned workout days without losing data** — Let an athlete mark an unstarted planned day as Skipped from the plan view after a clear confirmation. Display skipped days and sessions in a muted gray state, keep them out of Progress and max calculations, and offer Undo skip so the original day can still be started later. Do not allow skipping an in-progress draft or completed workout, and preserve all logged history.

- [x] **Published Web account and workout reliability** — On the public same-origin website, use the secure session cookie rather than sending a locally cached bearer token that the hosting proxy may reject before the Lift Log API receives the request. Preserve bearer-token authentication for native and explicit cross-origin API clients so account creation, sign-in, workout save, and tRPC data requests remain functional everywhere.

## Mutual sharing, private workouts, and friendly competition

- [x] **Clean load entry** — Normalize kilogram-to-pound and kilogram-to-kilogram values before they reach controlled set inputs or user-facing metrics. A user-entered 20 lb must continue to display as `20`, never as a long floating-point decimal, while canonical kilograms remain accurate.

- [x] **Automatic mutual activity sharing with per-workout privacy** — When a friend request is accepted, automatically enable summary activity sharing for both accepted friends. New completed workouts and PRs should appear by default without a per-activity sharing task. Add a clear per-workout Private switch that keeps that workout and its PR/feed cards out of Friends; changing an already shared workout to private must remove social cards and their interactions but never alter the workout log or Progress. Preserve the rule that feeds never expose ordinary set loads/reps, RPE, notes, or plans.

- [x] **Friend maxes and any-lift challenges** — Show an accepted friend’s estimated 1RMs by lift and equipment variation when they share activity. Let athletes challenge any matching weighted lift both people have completed, not only Bench Press, Back Squat, and Deadlift. Maintain mutual-friend access, explicit challenge acceptance, 30-day private scoreboards, and scores sourced only from completed logs.

- [x] **Kudos and playful leader taunts** — Keep short comments and preset reactions; label the supportive reaction as Kudos. On an active challenge where a completed lift places the athlete ahead, show an obvious preset-taunt prompt such as “I took the lead.” Keep taunts preset, removable only through ending the challenge, and visible only to the two accepted participants.

## Phase 1 — Fix bugs and make logging simple
- [x] Solo start opens a local empty workout, not Plans; persistence begins at Finish, and empty unfinished records are cleaned without deleting completed records or exercised drafts.
- [x] Replace the global five-area tour with two inline screen-specific tips; skipping persists per account and tips cannot cover Finish or Save.
- [x] Plot one best set per workout and use the same grouping for latest/best summaries; preserve per-set history.
- [x] Share with friends On/Off is consistent across workout and Settings; no friends displays Off, and explicit Off survives hub reads and later accepted requests.
- [x] First-name greeting says Hi; Today focuses on recent workouts and does not show plan-building content to new users.
- [x] Remove optional email-verification prompts; support decimal weight inputs, half-steps, +/−5 lb or 2.5 kg and light-weight 2.5 lb controls.
- [x] Set logging shows Weight and Reps, copies both values to new sets, offers optional Easy/Good/Hard, and keeps Finish workout in a reserved footer.
- [x] Show Last time beneath each exercise; keep workout name, notes, template saving, and sharing in secondary details.
- [x] Bottom navigation is Today, Progress, Friends, More; plans, templates, imports and settings live under More.
- [x] Replace user-facing technical strength terminology with Best lift, weight, reps and next time; Best lift has the specified help text.
- [x] New-account 390px walkthrough verified signup, no blank record on solo start, decimal entry/copy/save, single-workout chart, menu, dismissed tips, Last time, no horizontal overflow and ≥44px workout/nav targets. Fixed confirmed review findings before saving.

## Phase 2
- [x] A — Remove all everyday weight grids. On workout and exercise Progress show one Next time sentence, Use it for only the first set and a Why? one-line rule. Easy +5 lb/2.5 kg; Easy squat/deadlift/leg press +10 lb/5 kg. Good/no answer +5 lb/2.5 kg only if every latest-workout set reaches 8 reps; otherwise hold. Hard holds; no history renders nothing.
- [x] B — Finish shows Nice work, total weight lifted, sets and measured time; one approximately one-second check animation; New best badges for new heaviest weights; completed-workout count this calendar week; one main Share with friends if friends exist, otherwise Done.
- [x] C — One Progress screen per exercise with a simple line chart, one point per workout, big Best lift and next-time sentence; remove confusing chart labels/jargon; preserve detailed history as secondary.
- [x] D — Light background, one green accent, space, one main button, >=16px text, >=44px taps; empty screens one sentence and one action. First-run lb/kg choice persisted and never asked again; preserve existing units. Test a fresh user at390px and fix findings before stopping at Phase2.

Phase 2 evidence: TypeScript, lint, 65 tests, API bundle and Web export pass. A fresh 390px account completed first-run pounds selection, 135×8 Easy ->140 next time, first-set-only Use it preserving second-set130, Finish totals/time/new best/weeklycount, second Hard workout ->hold140, two-point chart, persisted unit after reload, no horizontal overflow and all visible workout controls>=44px. Isolated database checks cover older-draft new-best ordering and three concurrent shares producing one completion and one best-lift card. Existing units and logged history preserved.

## Phase 3 — Current acceptance criteria (supersede older social scope)
- [x] P3-A — Add friends by share link or invite code, not only email. Invite a friend gives a link for text. Friends lists names and Invite a friend; empty state exactly “Lifting is better with friends. Invite someone.” Mutual approval required. Fake test accounts only; no real email.
- [x] P3-B — Feed newest first, each card friend's name, action (e.g. “Sam did Bench press: 3 sets, best 145 lb × 8”), time, New best if applicable. Only Kudos (one tap and named givers) and Comment (short text plus Strong!, Nice lift, Beast mode chips). Only chosen shared workouts; respect Phase 1 Share with friends.
- [x] P3-C — Friend profile main lifts bench press, squat, deadlift, overhead press next to yours, “You: 135 lb. Sam: 145 lb.” Equipment-specific, no charts, two numbers.
- [x] P3-D — Friend lift Challenge: “Beat my 145 lb bench press by Sunday.” In-app notice Accept/Not now. A new shared lift exceeding friend's challenge number produces “You beat Sam’s bench press today.” Friend can Rematch. Friendly taunts only presets “Catch me if you can”, “Your turn”; Mute and Block on every friend.
- [x] P3-E — About 14 days without logged workout => profile Send a nudge when allowed. One tap preset Where are you bro? or Gym misses you, no free text. Let friends nudge me Settings Off default; both opt in. One per friend per week; mute/block support. Recipient sees only sender and line, never inactivity reason/duration. Warm, funny, not shaming.
- [x] P3-F — No unshared/private activity, weight loss, body weight, notes or personal data; lifts only. At most one notification/day default, clear Settings on/off. Accepted friendship and blocks checked on every social endpoint, including legacy. Preserve history and Phase 1/2. >=16px text, >=44px taps, one main job/button at 390px.
- [x] P3-review — Independent read-only connection/security review, fix confirmed findings. Final whole-app fresh-user 390px phone walkthrough, report remaining confusion. Save checkpoint, do not publish or start another phase.

Phase 3 evidence: 70 unit tests, nine fake-account social integration groups, TypeScript/lint/API build/Web export/Drizzle/diff checks, independent read-only review with confirmed fixes, actual 390px multi-account walkthrough and a final fresh kg account. No real emails; all owned fixtures cleaned up. See phase-3.md for plain changes, corrected findings and precise coverage. Preview/checkpoint only; not published.

## Requested fixes — 8 October 2026
- [x] RF-1 — Every Best lift is the heaviest actual logged weight; no formula estimate or worked-out wording. First log is starting best. Progress one actual heaviest point per workout, footer Started at 5 lb, now 10 lb. (dynamic) or Starting line set. for one.
- [x] RF-2 — Home top This week card lists plan weekdays/highlights next workout and large Start/resume; no plan says Pick a plan or just start with two buttons. Plans in bottom tab bar, not More, active plan one tap Home.
- [x] RF-3 — Trainer week paste/photo/file becomes scheduled workouts only after editable preview: We found 4 workouts. Check them, then Save. (dynamic count). Every detail editable before saving.
- [x] RF-4 — All prefilled numeric controls select all focus; first typing replaces number, no leading 1/0; decimals 12.5 supported for weight. Keep Next time simple Easy +5 lb, Hard hold, Easy legs +10 lb; weight step buttons -5/+5 lb or -2.5/+2.5 kg. No unrelated changes.

## First lift before signup
- [x] FL-1 — New user can log a real set and reach reward within 90 seconds, no account wall. Screen1 Hi. Let's get your first lift down.; lb/kg and How many days a week would feel good? 2/3/4 large buttons; Skip both. Screen2 What are you lifting today? eight common lift tiles squat/bench/deadlift/shoulder press/row/lat pulldown/leg press/lateral raise plus Something else and trainer upload.
- [x] FL-2 — Screen3 blank huge Weight/Reps and Log set only, no RPE/extras. Screen4 Starting line set. actual entered weight/reps, one-second gentle confetti and soft haptic; caption This is your best lift so far. We'll show you the real climb from here.; Log another set and Finish. Respect Reduce Motion. No calculated achievement/fake data.
- [x] FL-3 — Finish Week 1 has started: 1 of [chosen days]. (no invented count if skipped); one invite card Lifting is easier when one person notices. Invite a friend, share-link and Not now. Signup only after this, reason Save your lifts. Guest use continues; sets persist and safely transfer to created/existing account, private by default. Sign in with Apple native iOS with real token verification; record unsupported web/device/setup limits honestly.
- [x] FL-4 — Provide actual phone-width screenshots of every requested screen and account handoff; verify fresh guest journey, reload preservation, real server sync/account transfer, and independent connection review. No publication without request.

First-lift delivery evidence: 390px actual six-screen captures; blank fields, first real 12.5×10 moment before network/signup, skips/custom/zero/second set, reload persistence, guest upload, signup same-user preservation and existing-account claim passed. 76 tests, typecheck/lint/server build/Expo export pass. Durable invite alias and MySQL single-use Apple challenge smoke pass. Native Apple entitlement, haptic and actual iPhone/TestFlight flow require a real iOS device/build; web screenshots cannot verify those.
