import { AuthGate } from "@/components/lift-log/auth-gate";
import { AppButton, AppScreen, Card, colors, ui } from "@/components/lift-log/ui";
import { trpc } from "@/lib/trpc";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useState } from "react";
import { StyleSheet, Text, View } from "react-native";

function Invitation() {
  const router = useRouter();
  const { token } = useLocalSearchParams<{ token?: string }>();
  const [message, setMessage] = useState<string | null>(null);
  const respond = trpc.coach.respondToInvite.useMutation({
    onSuccess: (result) => { setMessage(result.accepted ? "You’re connected. Your coach can now view your training progress and create workout plans." : "Invitation declined. Your workout data stays private."); },
    onError: (error) => setMessage(error.message),
  });
  const valid = typeof token === "string" && token.length > 20;
  return <AppScreen contentStyle={styles.screen}><View style={styles.header}><Text style={ui.smallLabel}>Coach invitation</Text><Text style={ui.title}>Connect with your coach?</Text><Text style={ui.subtitle}>Accept to let this coach see your lift progress and create future workout plans. They can’t change workouts you’ve already logged.</Text></View><Card style={styles.card}>{message ? <Text style={styles.message}>{message}</Text> : null}<AppButton onPress={() => valid && respond.mutate({ token, accept: true })} disabled={!valid || respond.isPending}>{respond.isPending ? "Saving…" : "Accept invitation"}</AppButton><AppButton variant="secondary" onPress={() => valid && respond.mutate({ token, accept: false })} disabled={!valid || respond.isPending}>No thanks</AppButton><AppButton variant="ghost" onPress={() => router.replace("/" as never)}>Go to my workouts</AppButton></Card></AppScreen>;
}
export default function InvitationScreen() { return <AuthGate><Invitation /></AuthGate>; }
const styles = StyleSheet.create({ screen: { justifyContent: "center", gap: 18 }, header: { gap: 5 }, card: { gap: 12 }, message: { color: colors.limeDark, fontSize: 16, fontWeight: "700", lineHeight: 20 } });
