import { AuthGate } from "@/components/lift-log/auth-gate";
import { AppButton, AppScreen, Card, colors, ui } from "@/components/lift-log/ui";
import { useAuth } from "@/hooks/use-auth";
import { trpc } from "@/lib/trpc";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { useRouter } from "expo-router";
import { Platform, StyleSheet, Text, View } from "react-native";
import { useState } from "react";

function Privacy() {
  const router = useRouter();
  const { logout } = useAuth();
  const [message, setMessage] = useState<string | null>(null);
  const [confirming, setConfirming] = useState(false);
  const exporter = trpc.account.exportData.useMutation({
    onSuccess: async (data) => {
      const content = JSON.stringify(data, null, 2);
      try {
        if (Platform.OS === "web") {
          const url = URL.createObjectURL(new Blob([content], { type: "application/json" }));
          const anchor = document.createElement("a");
          anchor.href = url; anchor.download = "lift-log-data.json"; anchor.click(); URL.revokeObjectURL(url);
          setMessage("Your data download has started.");
        } else {
          const path = `${FileSystem.cacheDirectory}lift-log-data.json`;
          await FileSystem.writeAsStringAsync(path, content, { encoding: FileSystem.EncodingType.UTF8 });
          if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(path, { mimeType: "application/json", dialogTitle: "Export Lift Log data" });
          else setMessage("Your download is ready on this device. Open Lift Log on the web to download it.");
        }
      } catch { setMessage("Your data was prepared, but the download could not start. Try again from the web app."); }
    },
    onError: (error) => setMessage(error.message),
  });
  const remove = trpc.account.deleteData.useMutation({
    onSuccess: async () => { await logout(); router.replace("/auth" as never); },
    onError: (error) => setMessage(error.message),
  });

  return <AppScreen>
    <View style={styles.header}><Text style={ui.title}>Privacy & data</Text><Text style={ui.subtitle}>Your workout details are private unless you choose a specific way to share them.</Text></View>
    <Card style={styles.card}><Text style={styles.title}>What Lift Log stores</Text><Text style={styles.detail}>Your account details, workout logs, templates, plans, completed sets, optional effort feedback, Friends connections, comments, reactions, and challenges. Any plan file you upload is private to your account.</Text></Card>
    <Card style={styles.card}><Text style={styles.title}>Who can see your data</Text><Text style={styles.detail}>By default, only you. Friends can connect only after both people approve. If you turn on Friends activity sharing, accepted friends see only completed workouts and best lifts—not your set details, reps, effort feedback, notes, or plans. A coach sees your progress only after you accept their email invitation and can edit future plans they create for you, never your completed records.</Text></Card>
    <Card style={styles.card}><Text style={styles.title}>Get a copy</Text><Text style={styles.detail}>Download a copy of your account, workouts, templates, plans, and progress history.</Text><AppButton variant="secondary" onPress={() => exporter.mutate()} disabled={exporter.isPending}>{exporter.isPending ? "Preparing your download…" : "Download my data"}</AppButton></Card>
    <Card style={styles.dangerCard}><Text style={styles.title}>Delete my account</Text><Text style={styles.detail}>This permanently deletes your account, logged workouts, plans, templates, progress, Friends connections, activity, challenges, coach connections, and links to uploaded plan files. Uploaded plan files become inaccessible immediately. Any retained copies are removed according to our secure retention policy. This cannot be undone.</Text>{message ? <Text style={styles.message}>{message}</Text> : null}{confirming ? <View style={styles.actions}><AppButton variant="secondary" style={styles.half} onPress={() => setConfirming(false)} disabled={remove.isPending}>Keep my account</AppButton><AppButton variant="danger" style={styles.half} onPress={() => remove.mutate({ confirmation: "DELETE" })} disabled={remove.isPending}>{remove.isPending ? "Deleting…" : "Permanently delete"}</AppButton></View> : <AppButton variant="danger" onPress={() => setConfirming(true)}>Delete my account</AppButton>}</Card>
    <AppButton variant="ghost" onPress={() => router.back()}>Back to settings</AppButton>
  </AppScreen>;
}
export default function PrivacyScreen() { return <AuthGate><Privacy /></AuthGate>; }
const styles = StyleSheet.create({ header: { gap: 4, marginTop: 4 }, card: { gap: 8 }, dangerCard: { gap: 10, borderColor: "#E8B7A8", backgroundColor: "#FFF6F2" }, title: { color: colors.ink, fontSize: 16, fontWeight: "800" }, detail: { color: colors.muted, fontSize: 16, lineHeight: 19 }, actions: { flexDirection: "row", gap: 8 }, half: { flex: 1, paddingHorizontal: 8 }, message: { color: colors.limeDark, fontSize: 16, fontWeight: "700", lineHeight: 18 } });
