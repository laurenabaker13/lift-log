import { AuthGate } from "@/components/lift-log/auth-gate";
import { FriendActivityCard } from "@/components/lift-log/friend-activity-card";
import {
  AppButton,
  AppScreen,
  Card,
  EmptyState,
  LoadingState,
  Pill,
  colors,
  ui,
} from "@/components/lift-log/ui";
import { useAuth } from "@/hooks/use-auth";
import { trpc } from "@/lib/trpc";
import { type FriendReaction } from "@/shared/social";
import { formatWeight } from "@/shared/strength";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "@/server/routers";

type Comparison = inferRouterOutputs<AppRouter>["friends"]["profile"]["comparisons"][number];

function FriendProfile() {
  const router = useRouter();
  const params = useLocalSearchParams<{ id: string }>();
  const friendId = Number(params.id);
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const profile = trpc.friends.profile.useQuery(
    { friendId },
    { enabled: Number.isInteger(friendId) && friendId > 0 },
  );
  const settings = trpc.settings.get.useQuery();
  const [message, setMessage] = useState<string | null>(null);
  const [challengeChoice, setChallengeChoice] = useState<Comparison | null>(
    null,
  );
  const [blockOpen, setBlockOpen] = useState(false);
  const refresh = () => {
    profile.refetch();
    utils.friends.hub.invalidate();
  };
  const createChallenge = trpc.friends.createChallenge.useMutation({
    onSuccess: (result) => {
      setMessage(result.message);
      setChallengeChoice(null);
      refresh();
    },
    onError: (error) => setMessage(error.message),
  });
  const sendNudge = trpc.friends.sendNudge.useMutation({
    onSuccess: () => {
      setMessage("Nudge sent.");
      refresh();
    },
    onError: (error) => setMessage(error.message),
  });
  const setMuted = trpc.friends.setMuted.useMutation({
    onSuccess: () => {
      setMessage(null);
      refresh();
    },
    onError: (error) => setMessage(error.message),
  });
  const block = trpc.friends.block.useMutation({
    onSuccess: () => {
      utils.friends.hub.invalidate();
      router.replace("/friends" as never);
    },
    onError: (error) => setMessage(error.message),
  });
  const remove = trpc.friends.remove.useMutation({
    onSuccess: () => {
      utils.friends.hub.invalidate();
      router.replace("/friends" as never);
    },
    onError: (error) => setMessage(error.message),
  });
  const react = trpc.friends.react.useMutation({
    onSuccess: refresh,
    onError: (error) => setMessage(error.message),
  });
  const comment = trpc.friends.comment.useMutation({
    onSuccess: () => { setMessage(null); refresh(); },
    onError: (error) => setMessage(error.message),
  });
  const deleteComment = trpc.friends.deleteComment.useMutation({
    onSuccess: refresh,
    onError: (error) => setMessage(error.message),
  });
  const rematch = trpc.friends.rematch.useMutation({
    onSuccess: () => { setMessage("Rematch sent. Your friend can accept in Friends."); refresh(); },
    onError: (error) => setMessage(error.message),
  });
  const sendChallengeNote = trpc.friends.sendChallengeNote.useMutation({
    onSuccess: refresh,
    onError: (error) => setMessage(error.message),
  });

  if (profile.isLoading)
    return (
      <AppScreen scroll={false}>
        <LoadingState label="Opening friend…" />
      </AppScreen>
    );
  if (!profile.data)
    return (
      <AppScreen>
        <EmptyState title="This friend is no longer available." detail="" />
        <AppButton
          variant="secondary"
          onPress={() => router.replace("/friends" as never)}
        >
          Back to Friends
        </AppButton>
      </AppScreen>
    );

  const friend = profile.data.profile;
  const unit = settings.data?.unit ?? "lb";
  const muted = profile.data.muted;
  const canNudge = profile.data.canNudge;
  const comparisons = profile.data.comparisons;
  const activeChallenges = profile.data.challenges.filter(
    (challenge) =>
      challenge.status === "active" || challenge.status === "pending",
  );

  return (
    <AppScreen>
      <AppButton
        variant="ghost"
        style={styles.back}
        onPress={() => router.back()}
      >
        ‹ Friends
      </AppButton>
      <Card style={styles.hero}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>
            {friend.name.slice(0, 1).toUpperCase()}
          </Text>
        </View>
        <View style={ui.grow}>
          <Text style={styles.name}>{friend.name}</Text>
          <Text style={styles.detail}>
            {muted
              ? "Nudges and friendly lines muted"
              : friend.sharesActivity
                ? "Shares completed workouts"
                : "Keeps workout activity private"}
          </Text>
        </View>
      </Card>
      {message ? (
        <Card style={styles.message}>
          <Text style={styles.messageText}>{message}</Text>
        </Card>
      ) : null}

      {comparisons.length ? (
        <View style={styles.comparisonWrap}>
          <Text style={styles.sectionTitle}>Compare lifts</Text>
          {comparisons.map((comparison) => {
            const canChallenge =
              typeof comparison.viewerSharedBest === "number" && comparison.friendBest !== null;
            const selected =
              challengeChoice?.exerciseName === comparison.exerciseName &&
              challengeChoice?.equipment === comparison.equipment;
            const hasOpenChallenge = activeChallenges.some((challenge) => challenge.exerciseName === comparison.exerciseName && challenge.equipment === comparison.equipment);
            return (
              <Card
                key={`${comparison.exerciseName}-${comparison.equipment}`}
                style={styles.comparisonCard}
              >
                <Text style={styles.summaryName}>
                  {comparison.exerciseName} · {comparison.equipment}
                </Text>
                <Text style={styles.scoreLine}>
                  You: {formatWeight(comparison.viewerBest, comparison.unit)}.{" "}
                  {friend.name}:{" "}
                  {formatWeight(comparison.friendBest, comparison.unit)}.
                </Text>
                {canChallenge && !selected && !hasOpenChallenge ? (
                  <AppButton
                    variant="secondary"
                    style={styles.inlineAction}
                    onPress={() => setChallengeChoice(comparison)}
                  >
                    Challenge
                  </AppButton>
                ) : null}
                {selected ? (
                  <View style={styles.challengeConfirm}>
                    <Text style={styles.confirmText}>
                      Beat my{" "}
                      {formatWeight(comparison.viewerSharedBest, comparison.unit)}{" "}
                      {comparison.exerciseName.toLowerCase()} by Sunday.
                    </Text>
                    <Text style={ui.mutedText}>Only a new workout counts.</Text>
                    <AppButton
                      style={styles.sendChallenge}
                      onPress={() =>
                        createChallenge.mutate({
                          friendId,
                          exerciseName: comparison.exerciseName,
                          equipment: comparison.equipment,
                          timeZoneOffsetMinutes: new Date().getTimezoneOffset(),
                        })
                      }
                      disabled={createChallenge.isPending}
                    >
                      {createChallenge.isPending
                        ? "Sending…"
                        : "Send challenge"}
                    </AppButton>
                    <AppButton
                      variant="ghost"
                      style={styles.notNow}
                      onPress={() => setChallengeChoice(null)}
                    >
                      Not now
                    </AppButton>
                  </View>
                ) : null}
              </Card>
            );
          })}
        </View>
      ) : null}

      {!muted && canNudge ? (
        <Card style={styles.nudgeCard}>
          <Text style={styles.sectionTitle}>Nudge {friend.name}</Text>
          <Text style={ui.mutedText}>“Gym misses you.”</Text>
          <AppButton variant="secondary" style={styles.inlineAction}
            onPress={() => sendNudge.mutate({ friendId, preset: "gym_misses_you" })}
            disabled={sendNudge.isPending}>
            {sendNudge.isPending ? "Sending…" : "Send a nudge"}
          </AppButton>
        </Card>
      ) : null}
      {!muted && !canNudge && profile.data.nudgeUnavailableLine ? (
        <Text style={styles.unavailableLine}>
          {profile.data.nudgeUnavailableLine}
        </Text>
      ) : null}

      {activeChallenges.length ? (
        <Card style={styles.challengePanel}>
          <Text style={styles.sectionTitle}>Challenges</Text>
          {activeChallenges.map((challenge) => {
            const isActive = challenge.status === "active";
            return (
              <View key={challenge.id} style={styles.challengeBlock}>
                <View style={styles.challengeSummary}>
                  <Text style={styles.summaryName}>
                    {challenge.exerciseName} · {challenge.equipment}
                  </Text>
                  <Pill
                    label={isActive ? "Active" : "Waiting"}
                    active={isActive}
                  />
                </View>
                {isActive ? <Text style={styles.scoreLine}>
                  You: {formatWeight(challenge.viewerScore, challenge.unit)}.{" "}
                  {friend.name}: {formatWeight(challenge.otherScore, challenge.unit)}.
                </Text> : <Text style={ui.mutedText}>{challenge.opponentId === user?.id ? "Review this challenge in Friends." : `Waiting for ${friend.name} to accept.`}</Text>}
                {!isActive && challenge.opponentId === user?.id ? <AppButton variant="secondary" onPress={() => router.push("/friends" as never)}>Review challenge</AppButton> : null}
                {!muted && challenge.notes.length ? (
                  <View style={styles.notes}>
                    {challenge.notes.slice(-2).map((note) => (
                      <Text key={note.id} style={styles.note}>
                        <Text style={styles.noteAuthor}>
                          {note.author.name}:{" "}
                        </Text>
                        {note.label}
                      </Text>
                    ))}
                  </View>
                ) : null}
                {!muted && isActive ? (
                  <View style={styles.noteActions}>
                    <AppButton
                      variant="secondary"
                      style={styles.noteButton}
                      onPress={() =>
                        sendChallengeNote.mutate({
                          challengeId: challenge.id,
                          preset: "coming_for_you",
                        })
                      }
                      disabled={sendChallengeNote.isPending}
                    >
                      Catch me if you can
                    </AppButton>
                    <AppButton
                      variant="secondary"
                      style={styles.noteButton}
                      onPress={() =>
                        sendChallengeNote.mutate({
                          challengeId: challenge.id,
                          preset: "your_turn",
                        })
                      }
                      disabled={sendChallengeNote.isPending}
                    >
                      Your turn
                    </AppButton>
                  </View>
                ) : null}
              </View>
            );
          })}
        </Card>
      ) : null}

      <View style={styles.activityWrap}>
        <Text style={styles.sectionTitle}>Activity</Text>
        {friend.sharesActivity ? (
          profile.data.activities.length ? (
            profile.data.activities.map((activity) => (
              <FriendActivityCard
                key={activity.id}
                activity={activity}
                unit={unit}
                viewerId={user?.id}
                onReact={(activityId, kind: FriendReaction) =>
                  react.mutate({ activityId, kind })
                }
                onComment={(activityId, text) =>
                  comment.mutateAsync({ activityId, message: text })
                }
                onDeleteComment={(commentId) =>
                  deleteComment.mutate({ commentId })
                }
                onRematch={(challengeId) => rematch.mutate({ challengeId, timeZoneOffsetMinutes: new Date().getTimezoneOffset() })}
                rematching={rematch.isPending}
                rematchOpen={activeChallenges.some((challenge) => challenge.exerciseName === activity.exerciseName && challenge.equipment === activity.equipment)}
                reacting={react.isPending}
                commenting={comment.isPending}
              />
            ))
          ) : (
            <EmptyState
              title="Your friend’s workouts will appear here."
              detail=""
            />
          )
        ) : (
          <EmptyState
            title={`${friend.name} keeps their workouts private.`}
            detail=""
          />
        )}
      </View>

      <Card style={styles.safetyCard}>
        <Text style={styles.sectionTitle}>Friend controls</Text>
        <AppButton
          variant="secondary"
          style={styles.safetyAction}
          onPress={() => setMuted.mutate({ friendId, muted: !muted })}
          disabled={setMuted.isPending}
        >
          {setMuted.isPending
            ? "Saving…"
            : muted
              ? "Unmute friend"
              : "Mute friend"}
        </AppButton>
        {blockOpen ? (
          <View style={styles.blockConfirm}>
            <Text style={styles.confirmText}>
              Blocking removes this friend, hides their activity, and prevents
              invites, nudges, and challenges.
            </Text>
            <AppButton
              variant="danger"
              style={styles.blockButton}
              onPress={() => block.mutate({ friendId })}
              disabled={block.isPending}
            >
              {block.isPending ? "Blocking…" : "Block friend"}
            </AppButton>
            <AppButton
              variant="ghost"
              style={styles.notNow}
              onPress={() => setBlockOpen(false)}
            >
              Not now
            </AppButton>
          </View>
        ) : (
          <AppButton
            variant="ghost"
            style={styles.dangerLink}
            onPress={() => setBlockOpen(true)}
          >
            Block friend
          </AppButton>
        )}
        <AppButton
          variant="ghost"
          style={styles.dangerLink}
          onPress={() => remove.mutate({ friendId })}
          disabled={remove.isPending}
        >
          {remove.isPending ? "Removing…" : "Remove friend"}
        </AppButton>
      </Card>
    </AppScreen>
  );
}

export default function FriendProfileScreen() {
  return (
    <AuthGate>
      <FriendProfile />
    </AuthGate>
  );
}

const styles = StyleSheet.create({
  back: { alignSelf: "flex-start", minHeight: 44, paddingHorizontal: 0 },
  hero: {
    flexDirection: "row",
    alignItems: "center",
    gap: 13,
    padding: 19,
    backgroundColor: colors.ink,
    borderColor: colors.ink,
  },
  avatar: {
    width: 54,
    height: 54,
    borderRadius: 27,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.lime,
  },
  avatarText: { color: colors.ink, fontSize: 23, fontWeight: "900" },
  name: {
    color: colors.panel,
    fontSize: 22,
    fontWeight: "900",
    letterSpacing: -0.45,
  },
  detail: { color: colors.muted, fontSize: 16, lineHeight: 19 },
  message: { backgroundColor: colors.paleLime, borderColor: "#D6E9B9" },
  messageText: {
    color: colors.limeDark,
    fontSize: 16,
    fontWeight: "700",
    lineHeight: 19,
  },
  comparisonWrap: { gap: 10 },
  comparisonCard: { gap: 9, padding: 18 },
  sectionTitle: {
    color: colors.ink,
    fontSize: 18,
    fontWeight: "800",
    letterSpacing: -0.2,
    flex: 1,
  },
  summaryName: { color: colors.ink, fontSize: 16, fontWeight: "800" },
  scoreLine: {
    color: colors.muted,
    fontSize: 16,
    fontWeight: "700",
    lineHeight: 20,
  },
  inlineAction: {
    alignSelf: "flex-start",
    minHeight: 44,
    borderRadius: 12,
    paddingHorizontal: 13,
  },
  challengeConfirm: { gap: 8, paddingTop: 3 },
  confirmText: {
    color: colors.ink,
    fontSize: 16,
    fontWeight: "700",
    lineHeight: 20,
  },
  sendChallenge: { minHeight: 44, borderRadius: 12 },
  notNow: { alignSelf: "flex-start", minHeight: 44, paddingHorizontal: 0 },
  nudgeCard: { gap: 9, padding: 18 },
  nudgeChoices: { gap: 8 },
  nudgeButton: {
    alignItems: "flex-start",
    minHeight: 44,
    borderRadius: 12,
    paddingHorizontal: 13,
  },
  unavailableLine: { color: colors.muted, fontSize: 16, lineHeight: 20 },
  challengePanel: { gap: 10, padding: 18 },
  challengeBlock: {
    gap: 8,
    paddingTop: 10,
    borderTopColor: colors.line,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  challengeSummary: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
  },
  notes: { gap: 3 },
  note: { color: colors.ink, fontSize: 16, lineHeight: 19 },
  noteAuthor: { fontWeight: "800" },
  noteActions: { flexDirection: "row", flexWrap: "wrap", gap: 7 },
  noteButton: { minHeight: 44, borderRadius: 12, paddingHorizontal: 12 },
  activityWrap: { gap: 10 },
  safetyCard: { gap: 8, padding: 18 },
  safetyAction: {
    alignSelf: "flex-start",
    minHeight: 44,
    borderRadius: 12,
    paddingHorizontal: 13,
  },
  dangerLink: { alignSelf: "flex-start", minHeight: 44, paddingHorizontal: 0 },
  blockConfirm: {
    gap: 8,
    paddingTop: 7,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.line,
  },
  blockButton: { minHeight: 44, borderRadius: 12 },
});
