import { AuthGate } from "@/components/lift-log/auth-gate";
import { AppButton, AppScreen, Card, LoadingState, colors, ui } from "@/components/lift-log/ui";
import { trpc } from "@/lib/trpc";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { Platform, Share, StyleSheet, Text, View } from "react-native";

function Invite() {
  const router = useRouter();
  const [message, setMessage] = useState<string | null>(null);
  const invite = trpc.friends.invite.useMutation({ onError: (error) => setMessage(error.message) });
  const { mutate } = invite;
  useEffect(() => { mutate(); }, [mutate]);
  const code = invite.data?.code;
  const origin = Platform.OS === "web" && typeof window !== "undefined" ? window.location.origin : "https://liftlog-uwz9xcwl.manus.space";
  const link = code ? `${origin}/friend-invite?code=${encodeURIComponent(code)}` : "";
  const share = async () => {
    try {
      const text = `Lift with me on Lift Log. ${link}\nOr enter my invite code: ${code}`;
      if (Platform.OS === "web") {
        if (navigator.share) await navigator.share({ title: "Lift Log", text, url: link });
        else if (navigator.clipboard) { await navigator.clipboard.writeText(link); setMessage("Link copied. Send it to your friend by text."); }
        else setMessage("Select the link below to copy it and send it by text.");
      } else await Share.share({ message: text });
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") return;
      setMessage("Select the link below to copy it and send it by text.");
    }
  };
  return <AppScreen>
    <AppButton variant="ghost" style={styles.back} onPress={() => router.back()}>‹ Friends</AppButton>
    <Text style={ui.title}>Invite a friend</Text>
    <Text style={ui.mutedText}>Send your link by text. You’ll approve their request in Friends.</Text>
    {invite.isPending ? <LoadingState label="Making your invitation…" /> : null}
    {code ? <>
      <AppButton onPress={share}>Share invite link</AppButton>
      <Card style={styles.card}><Text style={styles.label}>Your invite code</Text><Text selectable style={styles.code}>{code}</Text><Text style={ui.mutedText}>Your friend can enter this code in Friends instead.</Text></Card>
      <Card style={styles.card}><Text style={styles.label}>Your link</Text><Text selectable style={styles.link}>{link}</Text></Card>
    </> : invite.error ? <AppButton onPress={() => invite.mutate()}>Try again</AppButton> : null}
    {message ? <Text style={ui.mutedText}>{message}</Text> : null}
    <View><AppButton variant="secondary" onPress={() => router.push("/friend-invite" as never)}>Enter a friend’s code</AppButton></View>
  </AppScreen>;
}
export default function InviteScreen() { return <AuthGate><Invite /></AuthGate>; }
const styles = StyleSheet.create({ back: { alignSelf: "flex-start", paddingHorizontal: 0 }, card: { gap: 12 }, label: { fontSize: 16, lineHeight: 24, color: colors.ink, fontWeight: "700" }, code: { fontSize: 20, lineHeight: 28, color: colors.limeDark, fontWeight: "800" }, link: { fontSize: 16, lineHeight: 24, color: colors.limeDark } });
