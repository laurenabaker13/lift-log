import { AuthGate } from "@/components/lift-log/auth-gate";
import {
  AppButton,
  AppScreen,
  Card,
  SectionTitle,
  ui,
} from "@/components/lift-log/ui";
import { useAuth } from "@/hooks/use-auth";
import { trpc } from "@/lib/trpc";
import { useRouter } from "expo-router";
import { useEffect, useMemo, useState } from "react";
import { Modal, StyleSheet, Text, View } from "react-native";

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

function Today() {
  const router = useRouter();
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const settings = trpc.settings.get.useQuery();
  const recent = trpc.workout.listRecent.useQuery();
  const activePlan = trpc.program.getActive.useQuery();
  const [selected, setSelected] = useState<{ id: number; name: string } | null>(
    null,
  );
  useEffect(() => {
    if (settings.data?.unitChosen === 0) {
      router.replace("/onboarding" as never);
    }
  }, [router, settings.data?.unitChosen]);
  const remove = trpc.workout.delete.useMutation({
    onSuccess: () => {
      setSelected(null);
      utils.workout.listRecent.invalidate();
      utils.progress.list.invalidate();
    },
  });
  const copy = trpc.workout.copyToToday.useMutation({
    onSuccess: (workout) => {
      if (workout) router.push(`/workout/${workout.id}` as never);
    },
  });
  const startScheduledWorkout = trpc.program.startWorkout.useMutation({
    onSuccess: (workout) => {
      utils.workout.listRecent.invalidate();
      utils.program.getActive.invalidate();
      if (workout) router.push(`/workout/${workout.id}` as never);
    },
  });
  const firstName = user?.name?.trim().split(/\s+/)[0];
  const program = activePlan.data;
  const activeWeek = useMemo(() => {
    if (!program?.weeks.length) return null;

    // A week stays active until every scheduled workout is completed or skipped.
    // We deliberately do not use calendar dates: a gap in a routine is not a failure.
    const unfinishedWeeks = program.weeks.filter((week) =>
      week.workouts.some(
        (workout) => !workout.latestSession?.completedAt && !workout.skippedAt,
      ),
    );
    return (
      unfinishedWeeks.find((week) =>
        week.workouts.some(
          (workout) => Boolean(workout.latestSession) && !workout.latestSession?.completedAt,
        ),
      ) ??
      unfinishedWeeks[0] ??
      program.weeks[program.weeks.length - 1]
    );
  }, [program]);
  const nextWorkout = useMemo(() => {
    if (!activeWeek) return null;
    const unfinished = activeWeek.workouts.filter(
      (workout) => !workout.latestSession?.completedAt && !workout.skippedAt,
    );
    return (
      unfinished.find(
        (workout) => Boolean(workout.latestSession) && !workout.latestSession?.completedAt,
      ) ?? unfinished[0] ?? null
    );
  }, [activeWeek]);

  return (
    <AppScreen>
      <Text style={ui.title}>{firstName ? `Hi ${firstName}` : "Hi"}</Text>
      <AppButton onPress={() => router.push("/workout/new" as never)}>
        Start a workout
      </AppButton>
      {activePlan.isLoading ? (
        <Card style={styles.weekCard}>
          <Text style={styles.weekEyebrow}>This week</Text>
          <Text style={ui.mutedText}>Loading your plan…</Text>
        </Card>
      ) : activePlan.error && !program ? (
        <Card style={styles.weekCard}>
          <Text style={styles.weekEyebrow}>This week</Text>
          <Text style={ui.mutedText}>Couldn’t open your plan. Please try again.</Text>
          <AppButton variant="secondary" onPress={() => void activePlan.refetch()} disabled={activePlan.isFetching}>
            Try again
          </AppButton>
        </Card>
      ) : !program || !program.weeks.some((week) => week.workouts.length) ? (
        <Card style={styles.weekCard}>
          <Text style={styles.weekEyebrow}>This week</Text>
          <Text style={styles.emptyPlanText}>Pick a plan or just start</Text>
          <AppButton variant="secondary" onPress={() => router.push("/plans" as never)}>
            Pick a plan
          </AppButton>
        </Card>
      ) : activeWeek ? (
        <Card style={styles.weekCard}>
          <View style={styles.weekHeader}>
            <Text style={styles.weekEyebrow}>This week</Text>
            <Text style={styles.weekName}>{program.name}</Text>
            <Text style={styles.weekDetail}>{activeWeek.name}</Text>
          </View>
          {nextWorkout ? (
            <AppButton
              variant="secondary"
              style={styles.weekStartButton}
              onPress={() => startScheduledWorkout.mutate({ programWorkoutId: nextWorkout.id })}
              disabled={startScheduledWorkout.isPending}
            >
              {startScheduledWorkout.isPending ? "Opening workout…" : `Start planned workout · ${nextWorkout.name}`}
            </AppButton>
          ) : (
            <AppButton variant="secondary" onPress={() => router.push("/plans" as never)}>
              View plan
            </AppButton>
          )}
          {startScheduledWorkout.error ? <Text style={styles.weekError}>{startScheduledWorkout.error.message}</Text> : null}
          <View style={styles.weekDays}>
            {DAYS.map((day, dayIndex) => {
              const dayWorkouts = activeWeek.workouts.filter((workout) => workout.dayOfWeek === dayIndex);
              const isNextDay = dayWorkouts.some((workout) => workout.id === nextWorkout?.id);
              const allCompleted = dayWorkouts.length > 0 && dayWorkouts.every((workout) => Boolean(workout.latestSession?.completedAt));
              const allSkipped = dayWorkouts.length > 0 && dayWorkouts.every((workout) => Boolean(workout.skippedAt));
              const hasInProgress = dayWorkouts.some((workout) => Boolean(workout.latestSession) && !workout.latestSession?.completedAt);
              const state = isNextDay ? "Next" : hasInProgress ? "In progress" : allCompleted ? "Done" : allSkipped ? "Skipped" : dayWorkouts.length ? `${dayWorkouts.length} planned` : "Rest";
              return (
                <View key={day} style={[styles.weekDay, isNextDay && styles.weekDayNext]}>
                  <Text style={[styles.weekDayName, isNextDay && styles.weekDayNextText]}>{day.slice(0, 3)}</Text>
                  <View style={styles.weekDayDetails}>
                    <Text style={[styles.weekDayWorkout, isNextDay && styles.weekDayNextText]} numberOfLines={1}>
                      {dayWorkouts.length ? dayWorkouts.map((workout) => workout.name).join(" · ") : "Rest day"}
                    </Text>
                    <Text style={[styles.weekDayState, isNextDay && styles.weekDayNextText]}>{state}</Text>
                  </View>
                </View>
              );
            })}
          </View>
        </Card>
      ) : (
        <Card style={styles.weekCard}>
          <Text style={styles.weekEyebrow}>This week</Text>
          <Text style={styles.emptyPlanText}>Add a workout day to get your week moving.</Text>
          <AppButton variant="secondary" onPress={() => router.push("/plans" as never)}>
            Open Plans
          </AppButton>
        </Card>
      )}
      <SectionTitle title="Recent workouts" />
      {recent.isLoading ? (
        <Text style={ui.mutedText}>Opening your workouts…</Text>
      ) : null}
      {recent.error && !recent.data ? (
        <View style={{ gap: 8 }}>
          <Text style={ui.mutedText}>Couldn’t open your recent workouts. Please try again.</Text>
          <AppButton variant="secondary" onPress={() => void recent.refetch()} disabled={recent.isFetching}>
            Try again
          </AppButton>
        </View>
      ) : !recent.isLoading && !recent.data?.length ? (
        <Text style={ui.mutedText}>No workouts yet. Log your first one.</Text>
      ) : null}
      {recent.data?.map((workout) => (
        <Card key={workout.id} style={{ gap: 8 }}>
          <Text style={{ ...ui.link, fontSize: 18 }}>{workout.name}</Text>
          <Text style={ui.mutedText}>
            {new Intl.DateTimeFormat(undefined, {
              month: "short",
              day: "numeric",
            }).format(new Date(workout.performedAt))}
            {!workout.completedAt ? " · In progress" : ""}
          </Text>
          <AppButton
            variant="secondary"
            onPress={() => router.push(`/workout/${workout.id}` as never)}
          >
            Open workout
          </AppButton>
          <View style={{ flexDirection: "row", gap: 8 }}>
            <AppButton
              variant="ghost"
              style={{ flex: 1 }}
              onPress={() => copy.mutate({ sourceWorkoutId: workout.id })}
              disabled={copy.isPending}
            >
              Repeat today
            </AppButton>
            <AppButton
              variant="ghost"
              onPress={() =>
                setSelected({ id: workout.id, name: workout.name })
              }
            >
              Delete
            </AppButton>
          </View>
        </Card>
      ))}
      <Modal
        visible={Boolean(selected)}
        transparent
        onRequestClose={() => setSelected(null)}
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "rgba(20,32,26,.45)",
            justifyContent: "center",
            padding: 20,
          }}
        >
          <Card style={{ gap: 12 }}>
            <Text style={ui.title}>Delete workout?</Text>
            <Text style={ui.mutedText}>
              “{selected?.name}” will be removed.
            </Text>
            {remove.error ? (
              <Text style={ui.mutedText}>{remove.error.message}</Text>
            ) : null}
            <AppButton variant="secondary" onPress={() => setSelected(null)}>
              Keep it
            </AppButton>
            <AppButton
              variant="danger"
              disabled={remove.isPending}
              onPress={() => selected && remove.mutate({ id: selected.id })}
            >
              Delete workout
            </AppButton>
          </Card>
        </View>
      </Modal>
    </AppScreen>
  );
}
export default function TodayScreen() {
  return (
    <AuthGate>
      <Today />
    </AuthGate>
  );
}

const styles = StyleSheet.create({
  weekCard: { gap: 14, padding: 20 },
  weekHeader: { gap: 3 },
  weekEyebrow: { color: "#2F6A43", fontSize: 16, fontWeight: "800", letterSpacing: 0.4, textTransform: "uppercase" },
  weekName: { color: "#15211B", fontSize: 21, fontWeight: "800", letterSpacing: -0.35, lineHeight: 26 },
  weekDetail: { color: "#637067", fontSize: 16, lineHeight: 21 },
  emptyPlanText: { color: "#15211B", fontSize: 18, fontWeight: "800", letterSpacing: -0.2, lineHeight: 23 },
  weekDays: { gap: 8 },
  weekDay: { alignItems: "center", backgroundColor: "#F0F4F1", borderRadius: 14, flexDirection: "row", gap: 12, minHeight: 52, paddingHorizontal: 12, paddingVertical: 8 },
  weekDayNext: { backgroundColor: "#EAF3EC", borderColor: "#2F6A43", borderWidth: 1 },
  weekDayName: { color: "#637067", fontSize: 16, fontWeight: "800", width: 36 },
  weekDayDetails: { flex: 1, gap: 1 },
  weekDayWorkout: { color: "#15211B", fontSize: 16, fontWeight: "800", lineHeight: 20 },
  weekDayState: { color: "#637067", fontSize: 16, lineHeight: 20 },
  weekDayNextText: { color: "#2F6A43" },
  weekStartButton: { borderRadius: 16, minHeight: 56 },
  weekError: { color: "#D65745", fontSize: 16, fontWeight: "700", lineHeight: 21 },
});
