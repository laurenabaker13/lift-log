import { AuthGate } from "@/components/lift-log/auth-gate";
import { AppScreen, colors, ui } from "@/components/lift-log/ui";
import { trpc } from "@/lib/trpc";
import { useRouter } from "expo-router";
import { Pressable, StyleSheet, Text, View } from "react-native";

function Progress() {
  const router = useRouter();
  const progress = trpc.progress.list.useQuery();

  return (
    <AppScreen>
      <View style={styles.header}>
        <Text style={ui.title}>Progress</Text>
        <Text style={styles.subtitle}>Your workouts, by exercise.</Text>
      </View>

      {progress.isLoading ? (
        <Text style={styles.loading}>Loading your exercises…</Text>
      ) : null}

      {!progress.isLoading && !progress.data?.length ? (
        <View style={styles.empty}>
          <Text style={styles.emptyText}>
            Finish a workout to see your exercises here.
          </Text>
          <Pressable
            accessibilityRole="button"
            onPress={() => router.push("/workout/new" as never)}
            style={({ pressed }) => [
              styles.startButton,
              pressed && styles.pressed,
            ]}
          >
            <Text style={styles.startButtonText}>Start workout</Text>
          </Pressable>
        </View>
      ) : null}

      <View style={styles.list}>
        {progress.data?.map((item) => (
          <Pressable
            key={item.exerciseId}
            accessibilityRole="link"
            accessibilityLabel={`Open ${item.name} progress`}
            onPress={() => router.push(`/exercise/${item.exerciseId}` as never)}
            style={({ pressed }) => [
              styles.exerciseLink,
              pressed && styles.pressed,
            ]}
          >
            <View style={styles.exerciseCopy}>
              <Text style={styles.name}>{item.name}</Text>
              <Text style={styles.equipment}>{item.equipment}</Text>
            </View>
            <Text style={styles.chevron}>›</Text>
          </Pressable>
        ))}
      </View>
    </AppScreen>
  );
}

export default function ProgressScreen() {
  return (
    <AuthGate>
      <Progress />
    </AuthGate>
  );
}

const styles = StyleSheet.create({
  header: { gap: 5, marginTop: 4 },
  subtitle: { color: colors.muted, fontSize: 16, lineHeight: 23 },
  loading: { color: colors.muted, fontSize: 16, lineHeight: 23 },
  list: { gap: 10 },
  exerciseLink: {
    minHeight: 72,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.line,
    paddingVertical: 14,
  },
  exerciseCopy: { flex: 1, gap: 3 },
  name: { color: colors.ink, fontSize: 18, fontWeight: "800", lineHeight: 24 },
  equipment: { color: colors.muted, fontSize: 16, lineHeight: 22 },
  chevron: {
    color: colors.limeDark,
    fontSize: 30,
    fontWeight: "500",
    lineHeight: 32,
  },
  empty: { gap: 14, alignItems: "flex-start" },
  emptyText: { color: colors.muted, fontSize: 16, lineHeight: 23 },
  startButton: {
    minHeight: 44,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 14,
    backgroundColor: colors.ink,
    paddingHorizontal: 18,
  },
  startButtonText: { color: colors.panel, fontSize: 16, fontWeight: "800" },
  pressed: { opacity: 0.72 },
});
