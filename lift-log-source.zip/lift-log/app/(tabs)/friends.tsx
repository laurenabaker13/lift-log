import { AuthGate } from "@/components/lift-log/auth-gate";
import { FriendActivityCard, activityTime } from "@/components/lift-log/friend-activity-card";
import { AppButton, AppScreen, Card, EmptyState, LoadingState, SectionTitle, colors, ui } from "@/components/lift-log/ui";
import { useAuth } from "@/hooks/use-auth";
import { trpc } from "@/lib/trpc";
import { type ChallengeNotePreset } from "@/shared/social";
import { formatWeight, fromKilograms } from "@/shared/strength";
import { useRouter } from "expo-router";
import { useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "@/server/routers";

type Challenge = inferRouterOutputs<AppRouter>["friends"]["hub"]["challenges"][number];
function ChallengeCard({ challenge, userId, onRespond, onCancel, onNote, pending }: {
  challenge: Challenge; userId: number | undefined;
  onRespond: (id: number, accept: boolean) => void;
  onCancel: (id: number) => void;
  onNote: (id: number, preset: ChallengeNotePreset) => void; pending: boolean;
}) {
  const [linesOpen, setLinesOpen] = useState(false);
  const incoming = challenge.status === "pending" && challenge.opponentId === userId;
  const outgoing = challenge.status === "pending" && challenge.creatorId === userId;
  const active = challenge.status === "active";
  if (!incoming && !outgoing && !active) return null;
  const target = challenge.targetKg === null ? null : formatWeight(fromKilograms(challenge.targetKg, challenge.unit), challenge.unit);
  const deadline = new Date(challenge.endsAt).toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" });
  return <Card style={styles.stack}>
    <Text style={styles.name}>{challenge.exerciseName} · {challenge.equipment}</Text>
    <Text style={ui.mutedText}>{incoming && target ? `${challenge.otherPerson.name}: “Beat my ${target} ${challenge.exerciseName.toLowerCase()} by Sunday.”` : `With ${challenge.otherPerson.name}`}</Text>
    <Text style={styles.detail}>Ends {deadline}</Text>
    {incoming ? <View style={styles.row}><AppButton variant="secondary" style={styles.half} onPress={() => onRespond(challenge.id, false)} disabled={pending}>Not now</AppButton><AppButton variant="secondary" style={styles.half} onPress={() => onRespond(challenge.id, true)} disabled={pending}>Accept</AppButton></View> : null}
    {outgoing ? <Text style={ui.mutedText}>Waiting for {challenge.otherPerson.name} to accept.</Text> : null}
    {active ? <>
      <Text style={ui.mutedText}>You: {challenge.viewerScore === null ? "—" : formatWeight(challenge.viewerScore, challenge.unit)}. {challenge.otherPerson.name}: {challenge.otherScore === null ? "—" : formatWeight(challenge.otherScore, challenge.unit)}.</Text>
      {challenge.notes.slice(-2).map((note) => <Text key={note.id} style={ui.mutedText}>{note.author.name}: {note.label}</Text>)}
      <AppButton variant="ghost" style={styles.left} onPress={() => setLinesOpen((open) => !open)}>{linesOpen ? "Close" : "Send a friendly line"}</AppButton>
      {linesOpen ? <View style={styles.stack}>{([{ preset: "coming_for_you", label: "Catch me if you can" }, { preset: "your_turn", label: "Your turn" }] as const).map((line) => <AppButton key={line.preset} variant="secondary" onPress={() => onNote(challenge.id, line.preset)} disabled={pending}>{line.label}</AppButton>)}</View> : null}
    </> : null}
    {!incoming ? <AppButton variant="ghost" style={styles.left} onPress={() => onCancel(challenge.id)} disabled={pending}>{active ? "End challenge" : "Cancel request"}</AppButton> : null}
  </Card>;
}

function Friends() {
  const router = useRouter();
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const hub = trpc.friends.hub.useQuery();
  const settings = trpc.settings.get.useQuery();
  const [message, setMessage] = useState<string | null>(null);
  const [challengesOpen, setChallengesOpen] = useState(false);
  const [ownOpen, setOwnOpen] = useState(false);
  const [blockedOpen, setBlockedOpen] = useState(false);
  const refresh = () => { utils.friends.hub.invalidate(); utils.friends.profile.invalidate(); };
  const failed = (error: { message: string }) => setMessage(error.message);
  const respond = trpc.friends.respond.useMutation({ onSuccess: refresh, onError: failed });
  const react = trpc.friends.react.useMutation({ onSuccess: refresh, onError: failed });
  const comment = trpc.friends.comment.useMutation({ onSuccess: () => { setMessage(null); refresh(); }, onError: failed });
  const deleteComment = trpc.friends.deleteComment.useMutation({ onSuccess: refresh, onError: failed });
  const respondChallenge = trpc.friends.respondToChallenge.useMutation({ onSuccess: refresh, onError: failed });
  const cancelChallenge = trpc.friends.cancelChallenge.useMutation({ onSuccess: refresh, onError: failed });
  const sendNote = trpc.friends.sendChallengeNote.useMutation({ onSuccess: refresh, onError: failed });
  const rematch = trpc.friends.rematch.useMutation({ onSuccess: () => { setMessage("Rematch sent. Your friend can accept in Friends."); refresh(); }, onError: failed });
  const readNotice = trpc.friends.readNotice.useMutation({ onSuccess: refresh, onError: failed });
  const readNudge = trpc.friends.readNudge.useMutation({ onSuccess: refresh, onError: failed });
  const unblock = trpc.friends.unblock.useMutation({ onSuccess: refresh, onError: failed });
  if (hub.isLoading) return <AppScreen scroll={false}><LoadingState label="Opening Friends…" /></AppScreen>;
  if (!hub.data) return <AppScreen><EmptyState title="We couldn’t open Friends. Please try again." detail="" /><AppButton onPress={() => hub.refetch()}>Try again</AppButton></AppScreen>;
  const data = hub.data;
  const unit = settings.data?.unit ?? "lb";
  const incomingChallenges = data.challenges.filter((challenge) => challenge.status === "pending" && challenge.opponentId === user?.id);
  const otherChallenges = data.challenges.filter((challenge) => (challenge.status === "pending" || challenge.status === "active") && !incomingChallenges.some((incoming) => incoming.id === challenge.id));
  const feed = [...data.activities, ...data.myActivities.filter((activity) => activity.kind === "challenge_win")]
    .sort((a, b) => new Date(b.occurredAt).getTime() - new Date(a.occurredAt).getTime());
  const renderActivity = (activity: typeof data.activities[number], own = false) => <FriendActivityCard key={activity.id} activity={activity} unit={unit} viewerId={user?.id}
    onReact={(activityId, kind) => react.mutate({ activityId, kind })}
    onComment={(activityId, text) => comment.mutateAsync({ activityId, message: text })}
    onDeleteComment={(commentId) => deleteComment.mutate({ commentId })}
    onRematch={(challengeId) => rematch.mutate({ challengeId, timeZoneOffsetMinutes: new Date().getTimezoneOffset() })}
    rematching={rematch.isPending}
    rematchOpen={data.challenges.some((challenge) => (challenge.status === "pending" || challenge.status === "active") && challenge.exerciseName === activity.exerciseName && challenge.equipment === activity.equipment && ((challenge.creatorId === activity.actor.id && challenge.opponentId === activity.opponentId) || (challenge.opponentId === activity.actor.id && challenge.creatorId === activity.opponentId)))}
    reacting={react.isPending} commenting={comment.isPending} allowInteractions={!own} />;
  return <AppScreen>
    <Text style={ui.title}>Friends</Text>
    {message ? <Card><Text style={ui.mutedText}>{message}</Text></Card> : null}
    <AppButton onPress={() => router.push("/friends/invite" as never)}>Invite a friend</AppButton>
    <View style={styles.stack}>{data.friends.length ? data.friends.map((friend) => friend.person ? <Card key={friend.id} style={styles.friendRow}>
      <View style={styles.avatar}><Text style={styles.avatarText}>{friend.person.name.slice(0, 1).toUpperCase()}</Text></View>
      <Text style={[styles.name, styles.grow]}>{friend.person.name}</Text>
      <AppButton variant="secondary" style={styles.compact} onPress={() => router.push(`/friends/${friend.person!.id}` as never)}>View</AppButton>
    </Card> : null) : <EmptyState title="Lifting is better with friends. Invite someone." detail="" />}</View>
    {data.notices.length ? <View style={styles.stack}>{data.notices.map((notice) => <Card key={notice.id} style={styles.stack}><Text style={styles.name}>{notice.actor.name}</Text><Text style={ui.mutedText}>{notice.message}</Text><Text style={styles.detail}>{activityTime(notice.createdAt)}</Text><AppButton variant="ghost" style={styles.left} onPress={() => readNotice.mutate({ noticeId: notice.id })} disabled={readNotice.isPending}>Dismiss</AppButton></Card>)}</View> : null}
    {data.nudges.length ? <View style={styles.stack}><SectionTitle title="Friendly nudges" />{data.nudges.map((nudge) => <Card key={nudge.id} style={styles.stack}><Text style={styles.name}>{nudge.actor.name}</Text><Text style={ui.mutedText}>{nudge.message}</Text><AppButton variant="ghost" style={styles.left} onPress={() => readNudge.mutate({ nudgeId: nudge.id })} disabled={readNudge.isPending}>Dismiss nudge</AppButton></Card>)}</View> : null}
    {data.incoming.length ? <View style={styles.stack}><SectionTitle title="Friend requests" />{data.incoming.map((request) => request.person ? <Card key={request.id} style={styles.stack}><Text style={styles.name}>{request.person.name} wants to be friends.</Text><View style={styles.row}><AppButton variant="secondary" style={styles.half} onPress={() => respond.mutate({ requestId: request.id, accept: false })} disabled={respond.isPending}>Not now</AppButton><AppButton variant="secondary" style={styles.half} onPress={() => respond.mutate({ requestId: request.id, accept: true })} disabled={respond.isPending}>Accept</AppButton></View></Card> : null)}</View> : null}
    {data.outgoing.length ? <Card style={styles.stack}><Text style={styles.name}>Waiting for approval</Text>{data.outgoing.map((request) => <Text key={request.id} style={ui.mutedText}>{request.person?.name || "Your friend"}</Text>)}</Card> : null}
    {incomingChallenges.map((challenge) => <ChallengeCard key={challenge.id} challenge={challenge} userId={user?.id} onRespond={(challengeId, accept) => respondChallenge.mutate({ challengeId, accept })} onCancel={(challengeId) => cancelChallenge.mutate({ challengeId })} onNote={(challengeId, preset) => sendNote.mutate({ challengeId, preset })} pending={respondChallenge.isPending || cancelChallenge.isPending || sendNote.isPending} />)}
    {otherChallenges.length ? <View style={styles.stack}><AppButton variant="ghost" style={styles.left} onPress={() => setChallengesOpen((open) => !open)}>{challengesOpen ? "Hide challenges" : `Your challenges · ${otherChallenges.length}`}</AppButton>{challengesOpen ? otherChallenges.map((challenge) => <ChallengeCard key={challenge.id} challenge={challenge} userId={user?.id} onRespond={(challengeId, accept) => respondChallenge.mutate({ challengeId, accept })} onCancel={(challengeId) => cancelChallenge.mutate({ challengeId })} onNote={(challengeId, preset) => sendNote.mutate({ challengeId, preset })} pending={respondChallenge.isPending || cancelChallenge.isPending || sendNote.isPending} />) : null}</View> : null}
    {data.friends.length ? <View style={styles.stack}><SectionTitle title="Recent activity" />{feed.length ? feed.map((activity) => renderActivity(activity)) : <EmptyState title="Your friends’ shared workouts will appear here." detail="" />}</View> : null}
    {data.myActivities.length ? <View style={styles.stack}><AppButton variant="ghost" style={styles.left} onPress={() => setOwnOpen((open) => !open)}>{ownOpen ? "Hide your shared activity" : "Your shared activity"}</AppButton>{ownOpen ? data.myActivities.map((activity) => renderActivity(activity, true)) : null}</View> : null}
    {data.blocked.length ? <View style={styles.stack}><AppButton variant="ghost" style={styles.left} onPress={() => setBlockedOpen((open) => !open)}>{blockedOpen ? "Hide blocked friends" : "Blocked friends"}</AppButton>{blockedOpen ? data.blocked.map((friend) => <Card key={friend.id} style={styles.friendRow}><Text style={[styles.name, styles.grow]}>{friend.name}</Text><AppButton variant="secondary" style={styles.compact} onPress={() => unblock.mutate({ friendId: friend.id })} disabled={unblock.isPending}>Unblock</AppButton></Card>) : null}</View> : null}
  </AppScreen>;
}
export default function FriendsScreen() { return <AuthGate><Friends /></AuthGate>; }
const styles = StyleSheet.create({
  stack: { gap: 12 }, row: { flexDirection: "row", gap: 8 }, half: { flex: 1, paddingHorizontal: 10 }, grow: { flex: 1 },
  friendRow: { flexDirection: "row", alignItems: "center", gap: 12, padding: 16 }, name: { color: colors.ink, fontSize: 16, lineHeight: 24, fontWeight: "700" },
  detail: { color: colors.muted, fontSize: 16, lineHeight: 23 }, left: { alignSelf: "flex-start", paddingHorizontal: 0 }, compact: { paddingHorizontal: 12 },
  avatar: { width: 38, height: 38, borderRadius: 19, backgroundColor: colors.paleLime, justifyContent: "center", alignItems: "center" }, avatarText: { color: colors.limeDark, fontSize: 16, fontWeight: "800" },
});
