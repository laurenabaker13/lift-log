import { AuthGate } from "@/components/lift-log/auth-gate";
import { AppButton, AppScreen, Card, EmptyState, SectionTitle, colors, ui } from "@/components/lift-log/ui";
import { trpc } from "@/lib/trpc";
import { useRouter } from "expo-router";
import { useState } from "react";
import { Modal, StyleSheet, Text, View } from "react-native";

function Templates() {
  const router = useRouter();
  const utils = trpc.useUtils();
  const templates = trpc.template.list.useQuery();
  const [templateToDelete, setTemplateToDelete] = useState<{ id: number; name: string } | null>(null);
  const useTemplate = trpc.template.use.useMutation({
    onSuccess: (workout) => {
      if (workout) router.push(`/workout/${workout.id}` as never);
    },
  });
  const deleteTemplate = trpc.template.delete.useMutation({
    onSuccess: () => {
      setTemplateToDelete(null);
      utils.template.list.invalidate();
    },
  });

  return (
    <AppScreen>
      <View style={styles.header}>
        <Text style={ui.title}>Templates</Text>
        <Text style={ui.subtitle}>Save a setup to reuse next time.</Text>
      </View>
      <SectionTitle title="Saved templates" />
      {templates.isLoading ? <EmptyState title="Opening your templates…" detail="" /> : null}
      {!templates.isLoading && !templates.data?.length ? <View style={{gap:16}}><EmptyState title="No templates yet. Save a workout as a template." detail="" /><AppButton onPress={()=>router.push("/workout/new" as never)}>Start workout</AppButton></View> : null}
      {templates.data?.map((template) => (
        <Card key={template.id} style={styles.template}>
          <View style={ui.grow}>
            <Text style={styles.name}>{template.name}</Text>
            <Text style={styles.date}>Updated {new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" }).format(new Date(template.updatedAt))}</Text>
          </View>
          <View style={styles.templateActions}>
            <AppButton variant="secondary" style={styles.useButton} disabled={useTemplate.isPending} onPress={() => useTemplate.mutate({ templateId: template.id })}>Start workout</AppButton>
            <AppButton variant="danger" style={styles.deleteButton} disabled={deleteTemplate.isPending} onPress={() => setTemplateToDelete({ id: template.id, name: template.name })}>Delete</AppButton>
          </View>
        </Card>
      ))}
      <Modal visible={Boolean(templateToDelete)} transparent animationType="fade" onRequestClose={() => setTemplateToDelete(null)}>
        <View style={styles.modalShade}>
          <Card style={styles.deleteModal}>
            <Text style={styles.deleteTitle}>Delete template?</Text>
            <Text style={styles.deleteDetail}>“{templateToDelete?.name}” will be removed. Your completed workout history will not change.</Text>
            {deleteTemplate.error ? <Text style={styles.deleteError}>{deleteTemplate.error.message}</Text> : null}
            <View style={styles.modalActions}>
              <AppButton variant="secondary" style={styles.modalButton} onPress={() => setTemplateToDelete(null)} disabled={deleteTemplate.isPending}>Keep it</AppButton>
              <AppButton variant="danger" style={styles.modalButton} onPress={() => templateToDelete && deleteTemplate.mutate({ id: templateToDelete.id })} disabled={deleteTemplate.isPending}>{deleteTemplate.isPending ? "Deleting…" : "Delete template"}</AppButton>
            </View>
          </Card>
        </View>
      </Modal>
    </AppScreen>
  );
}

export default function TemplatesScreen() { return <AuthGate><Templates /></AuthGate>; }

const styles = StyleSheet.create({
  header: { gap: 3, marginTop: 4 },
  note: { gap: 6, backgroundColor: colors.paleInk, borderColor: colors.paleInk },
  noteTitle: { color: colors.ink, fontSize: 16, fontWeight: "800" },
  noteBody: { color: colors.muted, fontSize: 16, lineHeight: 19 },
  template: { gap: 13, padding: 18 },
  name: { color: colors.ink, fontSize: 18, fontWeight: "800", letterSpacing: -0.2 },
  date: { color: colors.muted, fontSize: 16, marginTop: 3 },
  templateActions: { flexDirection: "row", gap: 8, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.line, paddingTop: 10 },
  useButton: { flex: 1, minHeight: 44, borderRadius: 13, paddingHorizontal: 10 },
  deleteButton: { minHeight: 44, borderRadius: 13, paddingHorizontal: 14 },
  modalShade: { flex: 1, backgroundColor: "rgba(20,32,26,0.48)", alignItems: "center", justifyContent: "center", padding: 24 },
  deleteModal: { width: "100%", maxWidth: 390, gap: 10 },
  deleteTitle: { color: colors.ink, fontSize: 19, fontWeight: "800" },
  deleteDetail: { color: colors.muted, fontSize: 16, lineHeight: 20 },
  deleteError: { color: colors.rust, fontSize: 16, fontWeight: "700" },
  modalActions: { flexDirection: "row", gap: 8, marginTop: 4 },
  modalButton: { flex: 1, paddingHorizontal: 8 },
});
