import { AuthGate } from "@/components/lift-log/auth-gate";
import { AppButton, AppScreen, Card, colors, ui } from "@/components/lift-log/ui";
import { useRouter } from "expo-router";
import { StyleSheet, Text, View } from "react-native";

function More() {
  const router = useRouter();

  return (
    <AppScreen>
      <View style={styles.header}>
        <Text style={ui.smallLabel}>More</Text>
        <Text style={ui.title}>Make it yours</Text>
        <Text style={ui.subtitle}>Saved workouts and account choices live here.</Text>
      </View>

      <Card style={styles.card}>
        <Text style={styles.cardTitle}>Saved templates</Text>
        <Text style={styles.cardDetail}>Reuse workouts you want to do again.</Text>
        <AppButton variant="secondary" style={styles.button} onPress={() => router.push("/templates" as never)}>Open saved templates</AppButton>
      </Card>

      <Card style={styles.card}>
        <Text style={styles.cardTitle}>Import trainer plan</Text>
        <Text style={styles.cardDetail}>Bring in a plan your trainer has shared with you.</Text>
        <AppButton variant="secondary" style={styles.button} onPress={() => router.push("/plan/import" as never)}>Import a plan</AppButton>
      </Card>

      <Card style={styles.card}>
        <Text style={styles.cardTitle}>Settings</Text>
        <Text style={styles.cardDetail}>Choose your name, units, sharing, and account options.</Text>
        <AppButton variant="secondary" style={styles.button} onPress={() => router.push("/settings" as never)}>Open Settings</AppButton>
      </Card>
    </AppScreen>
  );
}

export default function MoreScreen() {
  return <AuthGate><More /></AuthGate>;
}

const styles = StyleSheet.create({
  header: { gap: 3, marginTop: 4 },
  card: { gap: 9, padding: 18 },
  cardTitle: { color: colors.ink, fontSize: 18, fontWeight: "800", letterSpacing: -0.2 },
  cardDetail: { color: colors.muted, fontSize: 16, lineHeight: 19 },
  button: { minHeight: 48, borderRadius: 14, marginTop: 2 },
});
