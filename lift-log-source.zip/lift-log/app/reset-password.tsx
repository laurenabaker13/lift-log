import * as Api from "@/lib/_core/api";
import { AppButton, AppInput, AppScreen, BrandMark, Card, colors, ui } from "@/components/lift-log/ui";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useState } from "react";
import { StyleSheet, Text, View } from "react-native";

export default function ResetPasswordScreen() {
  const router = useRouter();
  const { token } = useLocalSearchParams<{ token?: string }>();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  const hasToken = typeof token === "string" && token.length > 20;

  const submit = async () => {
    setPending(true); setError(null); setMessage(null);
    try {
      const result = hasToken ? await Api.resetPassword(token, password) : await Api.requestPasswordReset(email);
      setMessage(result.message);
      if (hasToken) setTimeout(() => router.replace("/auth" as never), 1200);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "We couldn’t complete that. Try again.");
    } finally { setPending(false); }
  };

  return <AppScreen contentStyle={styles.screen}>
    <View style={styles.hero}><BrandMark /><Text style={ui.title}>{hasToken ? "Choose a new password" : "Reset your password"}</Text><Text style={ui.subtitle}>{hasToken ? "Use a new password you have not used elsewhere." : "Enter your email. If it has a Lift Log account, we’ll send a reset link."}</Text></View>
    <Card style={styles.card}>
      {hasToken ? <AppInput label="New password" value={password} onChangeText={setPassword} secureTextEntry placeholder="8–128 characters" autoCapitalize="none" /> : <AppInput label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" placeholder="name@example.com" />}
      {message ? <Text style={styles.success}>{message}</Text> : null}
      {error ? <Text style={styles.error}>{error}</Text> : null}
      <AppButton onPress={submit} disabled={pending || (hasToken ? password.length < 8 : !email.trim())}>{pending ? "Working…" : hasToken ? "Save new password" : "Email me a reset link"}</AppButton>
      <AppButton variant="ghost" onPress={() => router.replace("/auth" as never)}>Back to sign in</AppButton>
    </Card>
  </AppScreen>;
}

const styles = StyleSheet.create({ screen: { justifyContent: "center", gap: 22 }, hero: { gap: 9 }, card: { gap: 14 }, error: { color: colors.rust, fontSize: 16, fontWeight: "700" }, success: { color: colors.limeDark, fontSize: 16, fontWeight: "700", lineHeight: 19 } });
