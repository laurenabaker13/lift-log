import { AuthGate } from "@/components/lift-log/auth-gate";
import {
  AppButton,
  AppInput,
  AppScreen,
  Card,
  EmptyState,
  LoadingState,
  colors,
  ui,
} from "@/components/lift-log/ui";
import { trpc } from "@/lib/trpc";
import { progressSummary } from "@/shared/progress";
import { formatWeight } from "@/shared/strength";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useState } from "react";
import { Modal, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

const DAYS = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];
function ClientDetail() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const athleteId = Number(id);
  const utils = trpc.useUtils();
  const client = trpc.coach.getClient.useQuery(
    { athleteId },
    { enabled: Number.isInteger(athleteId) && athleteId > 0 },
  );
  const [suggestOpen, setSuggestOpen] = useState(false);
  const [planOpen, setPlanOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [title, setTitle] = useState("Next workout idea");
  const [message, setMessage] = useState("");
  const [planName, setPlanName] = useState("");
  const [workoutName, setWorkoutName] = useState("");
  const [day, setDay] = useState(1);
  const [notice, setNotice] = useState<string | null>(null);
  const [bestLiftHelpOpen, setBestLiftHelpOpen] = useState(false);
  const suggest = trpc.coach.suggest.useMutation({
    onSuccess: () => {
      setSuggestOpen(false);
      setMessage("");
      setNotice("Suggestion saved.");
      client.refetch();
    },
    onError: (error) => setNotice(error.message),
  });
  const createPlan = trpc.coach.createProgram.useMutation({
    onSuccess: () => {
      setPlanOpen(false);
      setPlanName("");
      setNotice("Future plan created. Add the first workout day next.");
      client.refetch();
    },
    onError: (error) => setNotice(error.message),
  });
  const addWorkout = trpc.program.createWorkout.useMutation({
    onSuccess: (workout) => {
      utils.coach.getClient.invalidate({ athleteId });
      if (workout)
        router.push(
          `/plan/workout/${workout.id}?athleteId=${athleteId}` as never,
        );
    },
    onError: (error) => setNotice(error.message),
  });
  if (client.isLoading)
    return (
      <AppScreen scroll={false}>
        <LoadingState label="Loading athlete progress…" />
      </AppScreen>
    );
  if (!client.data)
    return (
      <AppScreen>
        <EmptyState
          title="This athlete is not available yet."
          detail=""
        />
      </AppScreen>
    );
  const { profile, progress, managedProgram, suggestions } = client.data;
  const unit = profile.settings.unit;
  return (
    <AppScreen>
      <View style={styles.top}>
        <AppButton
          variant="ghost"
          style={styles.back}
          onPress={() => router.back()}
        >
          ‹ Back
        </AppButton>
        <View style={styles.statusPill}><Text style={styles.statusPillText}>Invitation accepted</Text></View>
      </View>
      <View style={styles.header}>
        <Text style={ui.title}>{profile.name || "Athlete"}</Text>
        <Text style={ui.subtitle}>{profile.email}</Text>
      </View>
      {notice ? (
        <Card style={styles.notice}>
          <Text style={styles.noticeText}>{notice}</Text>
        </Card>
      ) : null}
      <View style={styles.actions}>
        <AppButton style={styles.half} onPress={() => setSuggestOpen(true)}>
          Suggest a next step
        </AppButton>
        <AppButton
          variant="secondary"
          style={styles.half}
          onPress={() =>
            managedProgram ? setAddOpen(true) : setPlanOpen(true)
          }
        >
          {managedProgram ? "Add workout day" : "Create future plan"}
        </AppButton>
      </View>
      <Card style={styles.scope}>
        <Text style={styles.scopeTitle}>What you can change</Text>
        <Text style={styles.scopeText}>
          Suggestions are optional. You can edit future plan sessions. Completed
          workouts stay as the athlete logged them.
        </Text>
      </Card>
      <View style={styles.bestLiftSection}><Text style={styles.section}>Best lifts</Text><Pressable accessibilityRole="button" accessibilityLabel="What is a best lift?" onPress={() => setBestLiftHelpOpen((open) => !open)} style={({ pressed }) => [styles.helpButton, pressed && styles.pressed]}><Text style={styles.helpButtonText}>?</Text></Pressable></View>
      {bestLiftHelpOpen ? <Text style={styles.helpText}>The heaviest weight actually lifted and logged.</Text> : null}
      {!progress.length ? (
        <EmptyState
          title="Completed workouts will appear here."
          detail=""
        />
      ) : null}
      {progress.slice(0, 6).map((lift) => (
        <Card key={lift.exerciseId} style={styles.lift}>
          <View style={styles.liftTop}>
            <View style={ui.grow}>
              <Text style={styles.liftName}>{lift.name}</Text>
              <Text style={styles.liftEquipment}>{lift.equipment}</Text>
            </View>
            <View style={styles.bestLiftValue}><Text style={styles.bestLiftLabel}>Best lift</Text><Text style={styles.liftMax}>{formatWeight(progressSummary(lift.history).best ?? 0, unit)}</Text></View>
          </View>
          <Text style={styles.liftDetail}>
            {lift.history.length} logged set
            {lift.history.length === 1 ? "" : "s"} · latest:{" "}
            {formatWeight(lift.history[0]?.actualWeight ?? 0, unit)} ×{" "}
            {lift.history[0]?.actualReps ?? 0} reps
          </Text>
        </Card>
      ))}
      <Text style={styles.section}>Future plan</Text>
      {managedProgram ? (
        <Card style={styles.plan}>
          <Text style={styles.planName}>{managedProgram.name}</Text>
          <Text style={styles.planText}>
            Active plan. Edit future targets only.
          </Text>
          {managedProgram.weeks.map((week) => (
            <View key={week.id} style={styles.week}>
              <Text style={styles.weekName}>{week.name}</Text>
              {week.workouts.map((workout) => (
                <View key={workout.id} style={styles.planWorkout}>
                  <View style={ui.grow}>
                    <Text style={styles.planWorkoutName}>
                      {DAYS[workout.dayOfWeek]} · {workout.name}
                    </Text>
                    <Text style={styles.planWorkoutDetail}>
                      {workout.exercises.length} planned lift
                      {workout.exercises.length === 1 ? "" : "s"}
                    </Text>
                  </View>
                  <AppButton
                    variant="secondary"
                    style={styles.editButton}
                    onPress={() =>
                      router.push(
                        `/plan/workout/${workout.id}?athleteId=${athleteId}` as never,
                      )
                    }
                  >
                    Edit
                  </AppButton>
                </View>
              ))}
            </View>
          ))}
        </Card>
      ) : (
        <EmptyState
          title="No plan yet. Create one when you’re ready."
          detail=""
        />
      )}
      <Text style={styles.section}>Your suggestions</Text>
      {!suggestions.length ? (
        <Text style={styles.none}>No suggestions yet.</Text>
      ) : (
        suggestions.map((item) => (
          <Card key={item.id} style={styles.suggestion}>
            <Text style={styles.suggestionTitle}>{item.title}</Text>
            <Text style={styles.suggestionText}>{item.message}</Text>
          </Card>
        ))
      )}
      <Modal
        visible={suggestOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setSuggestOpen(false)}
      >
        <View style={styles.shade}>
          <Card style={styles.dialog}>
            <Text style={styles.dialogTitle}>Suggest a next step</Text>
            <Text style={styles.dialogText}>
              Suggestions are optional; the athlete decides whether to use them.
            </Text>
            <AppInput
              label="Short title"
              value={title}
              onChangeText={setTitle}
              maxLength={120}
            />
            <AppInput
              label="Suggestion"
              value={message}
              onChangeText={setMessage}
              multiline
              maxLength={1200}
              placeholder="Try the same reps with a small weight increase if the last session felt manageable."
            />
            <View style={styles.dialogActions}>
              <AppButton
                variant="secondary"
                style={styles.half}
                onPress={() => setSuggestOpen(false)}
              >
                Cancel
              </AppButton>
              <AppButton
                style={styles.half}
                onPress={() => suggest.mutate({ athleteId, title, message })}
                disabled={!title.trim() || !message.trim() || suggest.isPending}
              >
                {suggest.isPending ? "Saving…" : "Send suggestion"}
              </AppButton>
            </View>
          </Card>
        </View>
      </Modal>
      <Modal
        visible={planOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setPlanOpen(false)}
      >
        <View style={styles.shade}>
          <Card style={styles.dialog}>
            <Text style={styles.dialogTitle}>Create a future plan</Text>
            <Text style={styles.dialogText}>
              Creates a new plan. Completed workouts stay unchanged.
            </Text>
            <AppInput
              label="Plan name"
              value={planName}
              onChangeText={setPlanName}
              placeholder="Strength Block"
            />
            <View style={styles.dialogActions}>
              <AppButton
                variant="secondary"
                style={styles.half}
                onPress={() => setPlanOpen(false)}
              >
                Cancel
              </AppButton>
              <AppButton
                style={styles.half}
                onPress={() => createPlan.mutate({ athleteId, name: planName })}
                disabled={!planName.trim() || createPlan.isPending}
              >
                {createPlan.isPending ? "Creating…" : "Create plan"}
              </AppButton>
            </View>
          </Card>
        </View>
      </Modal>
      <Modal
        visible={addOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setAddOpen(false)}
      >
        <View style={styles.shade}>
          <Card style={styles.dialog}>
            <Text style={styles.dialogTitle}>Add a plan day</Text>
            <AppInput
              label="Workout name"
              value={workoutName}
              onChangeText={setWorkoutName}
              placeholder="Lower body"
            />
            <Text style={styles.dayLabel}>Day</Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.dayPills}
            >
              {DAYS.map((name, index) => <AppButton key={name} variant={day === index ? "primary" : "secondary"} style={styles.dayButton} onPress={() => setDay(index)}>{name.slice(0, 3)}</AppButton>)}
            </ScrollView>
            <View style={styles.dialogActions}>
              <AppButton
                variant="secondary"
                style={styles.half}
                onPress={() => setAddOpen(false)}
              >
                Cancel
              </AppButton>
              <AppButton
                style={styles.half}
                onPress={() =>
                  managedProgram &&
                  addWorkout.mutate({
                    weekId: managedProgram.weeks[0]?.id,
                    name: workoutName,
                    dayOfWeek: day,
                  })
                }
                disabled={
                  !workoutName.trim() || !managedProgram || addWorkout.isPending
                }
              >
                {addWorkout.isPending ? "Adding…" : "Add workout"}
              </AppButton>
            </View>
          </Card>
        </View>
      </Modal>
    </AppScreen>
  );
}
export default function ClientDetailScreen() {
  return (
    <AuthGate>
      <ClientDetail />
    </AuthGate>
  );
}
const styles = StyleSheet.create({
  top: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  back: { minHeight: 44, paddingHorizontal: 0 },
  statusPill: { borderRadius: 999, backgroundColor: colors.ink, paddingHorizontal: 12, paddingVertical: 7 },
  statusPillText: { color: colors.panel, fontSize: 16, fontWeight: "800" },
  header: { gap: 3 },
  actions: { flexDirection: "row", gap: 8 },
  half: { flex: 1, paddingHorizontal: 8 },
  notice: { backgroundColor: colors.paleLime, borderColor: "#DCEAB4" },
  noticeText: {
    color: colors.limeDark,
    fontSize: 16,
    fontWeight: "700",
    lineHeight: 19,
  },
  scope: { gap: 5, backgroundColor: colors.paleInk },
  scopeTitle: { color: colors.ink, fontSize: 16, fontWeight: "800" },
  scopeText: { color: colors.muted, fontSize: 16, lineHeight: 18 },
  bestLiftSection: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 4 },
  section: { color: colors.ink, fontSize: 17, fontWeight: "800", flex: 1 },
  helpButton: { width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center", backgroundColor: colors.paleInk },
  helpButtonText: { color: colors.limeDark, fontSize: 18, fontWeight: "900" },
  helpText: { color: colors.limeDark, fontSize: 16, fontWeight: "700", lineHeight: 19, backgroundColor: colors.paleLime, borderRadius: 12, padding: 10 },
  lift: { gap: 7 },
  liftTop: { flexDirection: "row", gap: 8, alignItems: "center" },
  liftName: { color: colors.ink, fontSize: 16, fontWeight: "800" },
  liftEquipment: { color: colors.muted, fontSize: 16, marginTop: 2 },
  bestLiftValue: { alignItems: "flex-end", gap: 2 },
  bestLiftLabel: { color: colors.muted, fontSize: 16, fontWeight: "800", textTransform: "uppercase", letterSpacing: 0.5 },
  liftMax: { color: colors.limeDark, fontSize: 17, fontWeight: "800" },
  liftDetail: { color: colors.muted, fontSize: 16, lineHeight: 17 },
  plan: { gap: 12 },
  planName: { color: colors.ink, fontSize: 18, fontWeight: "800" },
  planText: { color: colors.muted, fontSize: 16, lineHeight: 19 },
  week: { gap: 6 },
  weekName: {
    color: colors.limeDark,
    fontSize: 16,
    fontWeight: "800",
    textTransform: "uppercase",
  },
  planWorkout: {
    flexDirection: "row",
    gap: 8,
    alignItems: "center",
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.line,
    paddingTop: 8,
  },
  planWorkoutName: { color: colors.ink, fontSize: 16, fontWeight: "800" },
  planWorkoutDetail: { color: colors.muted, fontSize: 16, marginTop: 2 },
  editButton: { minHeight: 44, paddingHorizontal: 10, borderRadius: 10 },
  none: { color: colors.muted, fontSize: 16 },
  suggestion: { gap: 4 },
  suggestionTitle: { color: colors.ink, fontSize: 16, fontWeight: "800" },
  suggestionText: { color: colors.muted, fontSize: 16, lineHeight: 19 },
  shade: {
    flex: 1,
    backgroundColor: "rgba(20,21,18,0.42)",
    justifyContent: "center",
    padding: 24,
  },
  dialog: { gap: 12 },
  dialogTitle: { color: colors.ink, fontSize: 19, fontWeight: "800" },
  dialogText: { color: colors.muted, fontSize: 16, lineHeight: 19 },
  dialogActions: { flexDirection: "row", gap: 8 },
  dayLabel: { color: colors.ink, fontSize: 16, fontWeight: "800" },
  dayPills: { gap: 7 },
  dayButton: { minWidth: 52, minHeight: 44, borderRadius: 12, paddingHorizontal: 10 },
  pressed: { opacity: 0.72, transform: [{ scale: 0.985 }] },
});
