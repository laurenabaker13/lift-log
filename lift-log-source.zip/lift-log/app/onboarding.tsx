import { AuthGate } from "@/components/lift-log/auth-gate";
import { AppButton, AppScreen, Card, colors, ui } from "@/components/lift-log/ui";
import { trpc } from "@/lib/trpc";
import { pendingFriendDestination } from "@/lib/friend-invite";
import { useRouter } from "expo-router";
import { useState } from "react";
import { StyleSheet, Text, View } from "react-native";

function Onboarding() {
  const router = useRouter();
  const utils = trpc.useUtils();
  const [unit, setUnit] = useState<"lb" | "kg" | null>(null);
  const complete = trpc.account.completeOnboarding.useMutation({
    onSuccess: async () => {
      utils.account.profile.invalidate();
      router.replace((await pendingFriendDestination("/workout/new")) as never);
    },
  });
  const setWeightUnit = trpc.settings.setUnit.useMutation({
    onSuccess: () => {
      utils.settings.get.invalidate();
      complete.mutate();
    },
  });
  const pending = setWeightUnit.isPending || complete.isPending;

  const continueOnboarding = () => {
    if (unit) setWeightUnit.mutate({ unit });
  };

  return (
    <AppScreen contentStyle={styles.screen}>
      <View style={styles.hero}>
        <Text style={ui.title}>Your workout, made simple.</Text>
        <Text style={ui.subtitle}>Choose an exercise, then log your weight and reps.</Text>
      </View>
      <Card style={styles.card}>
        <Text style={styles.question}>Which weights do you use?</Text>
        <View style={styles.unitRow}>
          <AppButton
            variant="secondary"
            style={[styles.unitButton, unit === "lb" && styles.unitButtonSelected]}
            onPress={() => setUnit("lb")}
          >
            Pounds (lb)
          </AppButton>
          <AppButton
            variant="secondary"
            style={[styles.unitButton, unit === "kg" && styles.unitButtonSelected]}
            onPress={() => setUnit("kg")}
          >
            Kilograms (kg)
          </AppButton>
        </View>
        <Text style={ui.mutedText}>You can change this later in Settings.</Text>
        <AppButton onPress={continueOnboarding} disabled={!unit || pending}>
          {pending ? "Saving…" : "Continue"}
        </AppButton>
        {setWeightUnit.error || complete.error ? (
          <Text style={styles.error}>{(setWeightUnit.error ?? complete.error)?.message}</Text>
        ) : null}
      </Card>
    </AppScreen>
  );
}

export default function OnboardingScreen() {
  return (
    <AuthGate>
      <Onboarding />
    </AuthGate>
  );
}

const styles = StyleSheet.create({
  screen: { justifyContent: "center", flexGrow: 1, gap: 28 },
  hero: { gap: 8 },
  card: { gap: 18 },
  question: { color: colors.ink, fontSize: 20, fontWeight: "800", letterSpacing: -0.25 },
  unitRow: { flexDirection: "row", gap: 10 },
  unitButton: { flex: 1, minHeight: 50, borderRadius: 12, paddingHorizontal: 8 },
  unitButtonSelected: { backgroundColor: colors.paleLime, borderColor: colors.limeDark },
  error: { color: colors.rust, fontSize: 16, fontWeight: "700", lineHeight: 24 },
});
