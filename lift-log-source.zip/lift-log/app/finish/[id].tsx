import { AuthGate } from "@/components/lift-log/auth-gate";
import {
  AppButton,
  AppScreen,
  Card,
  LoadingState,
  colors,
  ui,
} from "@/components/lift-log/ui";
import { trpc } from "@/lib/trpc";
import { formatWeight } from "@/shared/strength";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useState } from "react";
import {
  AccessibilityInfo,
  Animated,
  StyleSheet,
  Text,
  View,
} from "react-native";

function Finish() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const utils = trpc.useUtils();
  const [week] = useState(() => {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
    const end = new Date(start);
    end.setDate(end.getDate() + 7);
    return { weekStart: start.toISOString(), weekEnd: end.toISOString() };
  });
  const summary = trpc.workout.finishSummary.useQuery({
    id: Number(id),
    ...week,
  });
  const share = trpc.workout.shareCompleted.useMutation();
  const [message, setMessage] = useState("");
  const [pop] = useState(() => new Animated.Value(1));
  const finishedId = summary.data?.id;
  useEffect(() => {
    if (!finishedId) return;
    let animation: Animated.CompositeAnimation | undefined;
    let active = true;
    AccessibilityInfo.isReduceMotionEnabled().then((reduced) => {
      if (reduced || !active) return;
      pop.setValue(0.75);
      animation = Animated.sequence([
        Animated.timing(pop, {
          toValue: 1.08,
          duration: 500,
          useNativeDriver: true,
        }),
        Animated.timing(pop, {
          toValue: 1,
          duration: 500,
          useNativeDriver: true,
        }),
      ]);
      animation.start();
    });
    return () => {
      active = false;
      animation?.stop();
    };
  }, [pop, finishedId]);
  if (summary.isLoading)
    return (
      <AppScreen>
        <LoadingState label="Your workout is saved…" />
      </AppScreen>
    );
  if (!summary.data)
    return (
      <AppScreen>
        <Text style={ui.title}>Your workout is saved.</Text>
        <Text style={ui.mutedText}>
          {summary.error?.message || "Open it from Today."}
        </Text>
        <AppButton onPress={() => router.replace("/" as never)}>Done</AppButton>
      </AppScreen>
    );
  const data = summary.data;
  const duration = data.durationSeconds;
  return (
    <AppScreen contentStyle={{ gap: 24, paddingTop: 32 }}>
      <Animated.View style={[styles.check, { transform: [{ scale: pop }] }]}>
        <Text style={styles.checkText}>✓</Text>
      </Animated.View>
      <View style={{ gap: 8 }}>
        <Text style={styles.title}>Nice work.</Text>
        <Text style={ui.subtitle}>Your workout is saved.</Text>
      </View>
      <Card style={{ gap: 20 }}>
        <View style={styles.row}>
          <Text style={styles.label}>Total weight lifted</Text>
          <Text style={styles.value}>
            {formatWeight(data.totalWeight, data.unit)}
          </Text>
        </View>
        <View style={styles.row}>
          <Text style={styles.label}>Sets</Text>
          <Text style={styles.value}>{data.sets}</Text>
        </View>
        <View style={styles.row}>
          <Text style={styles.label}>Time</Text>
          <Text style={styles.value}>
            {duration === null
              ? "Not recorded"
              : duration < 60
                ? `${duration} sec`
                : `${Math.floor(duration / 60)} min ${duration % 60} sec`}
          </Text>
        </View>
      </Card>
      {data.newBests.map((best) => (
        <View key={best.exerciseId} style={styles.best}>
          <Text style={styles.badge}>New best</Text>
          <Text style={styles.bestText}>
            {best.name}: {formatWeight(best.weight, data.unit)}
          </Text>
        </View>
      ))}
      <Text style={styles.streak}>
        {data.workoutsThisWeek} workout{data.workoutsThisWeek === 1 ? "" : "s"}{" "}
        this week
      </Text>
      {message ? (
        <Text accessibilityRole="alert" style={ui.mutedText}>
          {message}
        </Text>
      ) : null}
      <AppButton
        disabled={share.isPending}
        onPress={async () => {
          if (!data.hasFriends) {
            router.replace("/" as never);
            return;
          }
          try {
            await share.mutateAsync({ id: data.id });
            await utils.friends.hub.invalidate();
            router.replace("/friends" as never);
          } catch (error) {
            setMessage(
              error instanceof Error
                ? error.message
                : "Could not share. Your workout is still saved.",
            );
          }
        }}
      >
        {share.isPending
          ? "Sharing…"
          : data.hasFriends
            ? "Share with friends"
            : "Done"}
      </AppButton>
      {data.hasFriends ? (
        <AppButton variant="ghost" onPress={() => router.replace("/" as never)}>
          Not now
        </AppButton>
      ) : null}
      {share.error ? (
        <AppButton
          variant="ghost"
          onPress={() => router.push("/settings" as never)}
        >
          Sharing settings
        </AppButton>
      ) : null}
    </AppScreen>
  );
}
export default function FinishScreen() {
  return (
    <AuthGate>
      <Finish />
    </AuthGate>
  );
}
const styles = StyleSheet.create({
  check: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: colors.paleLime,
    alignItems: "center",
    justifyContent: "center",
  },
  checkText: { fontSize: 38, color: colors.limeDark },
  title: { fontSize: 36, fontWeight: "800", color: colors.ink },
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 14,
  },
  label: { fontSize: 16, color: colors.muted, flex: 1 },
  value: { fontSize: 20, color: colors.ink, fontWeight: "700" },
  best: { gap: 8 },
  badge: { fontSize: 16, color: colors.limeDark, fontWeight: "800" },
  bestText: { fontSize: 18, color: colors.ink },
  streak: { fontSize: 18, color: colors.ink, fontWeight: "700" },
});
