import { FirstLiftMoment } from "@/components/lift-log/first-lift-moment";
import { NumberInput } from "@/components/lift-log/number-input";
import { AppButton, AppScreen, Card, LoadingState, colors } from "@/components/lift-log/ui";
import {
  defaultGuestDraft,
  ensureGuestSession,
  readGuestDraft,
  saveGuestDraft,
  shareGuestInvite,
  syncGuestWorkout,
  type GuestDraft,
} from "@/lib/guest-log";
import { useRouter } from "expo-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { Pressable, StyleSheet, Text, TextInput, View } from "react-native";


type SyncState = "idle" | "syncing" | "failed";
type ExerciseChoice = { name: string; equipment: string };

const EXERCISES: ExerciseChoice[] = [
  { name: "Squat", equipment: "Barbell" },
  { name: "Bench press", equipment: "Barbell" },
  { name: "Deadlift", equipment: "Barbell" },
  { name: "Shoulder press", equipment: "Barbell" },
  { name: "Row", equipment: "Barbell" },
  { name: "Lat pulldown", equipment: "Cable" },
  { name: "Leg press", equipment: "Machine" },
  { name: "Lateral raise", equipment: "Cable" },
];

function setKey() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function formatNumber(value: number) {
  return String(value);
}

function setLine(set: GuestDraft["sets"][number], unit: GuestDraft["unit"]) {
  return `${formatNumber(set.weight)} ${unit} × ${set.reps}`;
}

function FirstLift() {
  const router = useRouter();
  const [draft, setDraft] = useState<GuestDraft | null>(null);
  const draftRef = useRef<GuestDraft | null>(null);
  const [unitAnswered, setUnitAnswered] = useState(false);
  const [daysAnswered, setDaysAnswered] = useState(false);
  const [customExercise, setCustomExercise] = useState(false);
  const [customName, setCustomName] = useState("");
  const [weight, setWeight] = useState("");
  const [reps, setReps] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [planPending, setPlanPending] = useState(false);
  const [syncState, setSyncState] = useState<SyncState>("idle");
  const [invitePending, setInvitePending] = useState(false);
  const [inviteComplete, setInviteComplete] = useState(false);

  const persist = useCallback((next: GuestDraft) => {
    draftRef.current = next;
    setDraft(next);
    void saveGuestDraft(next).catch(() => {
      setMessage("Couldn’t save locally. Please try again.");
    });
  }, []);

  useEffect(() => {
    let mounted = true;
    void readGuestDraft()
      .then((saved) => {
        if (!mounted) return;
        const next = saved ?? defaultGuestDraft();
        draftRef.current = next;
        setDraft(next);
      })
      .catch(() => {
        if (!mounted) return;
        const next = defaultGuestDraft();
        draftRef.current = next;
        setDraft(next);
      });
    return () => {
      mounted = false;
    };
  }, []);

  const selectUnit = (unit: GuestDraft["unit"]) => {
    if (!draft) return;
    setMessage(null);
    persist({ ...draft, unit });
    setUnitAnswered(true);
  };

  const chooseDays = (days: 2 | 3 | 4) => {
    if (!draft) return;
    setMessage(null);
    persist({ ...draft, days });
    setDaysAnswered(true);
  };

  const continueFromDays = () => {
    if (!draft || !unitAnswered || !daysAnswered) return;
    persist({ ...draft, stage: "choose" });
  };

  const skipDays = () => {
    if (!draft) return;
    persist({ ...draft, days: null });
    setDaysAnswered(true);
  };

  const chooseExercise = (exercise: ExerciseChoice) => {
    if (!draft) return;
    setMessage(null);
    setCustomExercise(false);
    setCustomName("");
    setWeight("");
    setReps("");
    persist({ ...draft, exercise, stage: "log", finishedAt: null });
  };

  const continueWithCustomExercise = () => {
    const name = customName.trim();
    if (!draft || !name) return;
    chooseExercise({ name, equipment: "Other" });
  };

  const openTrainerPlan = async () => {
    setPlanPending(true);
    setMessage(null);
    try {
      await ensureGuestSession();
      router.push("/plan/import" as never);
    } catch {
      setMessage("Couldn’t open plan import. Please try again.");
    } finally {
      setPlanPending(false);
    }
  };

  const logSet = () => {
    if (!draft?.exercise) return;
    const parsedWeight = Number(weight);
    const parsedReps = Number(reps);
    if (
      !weight.trim() ||
      !Number.isFinite(parsedWeight) ||
      parsedWeight < 0 ||
      parsedWeight > 5000 ||
      !reps.trim() ||
      !Number.isInteger(parsedReps) ||
      parsedReps <= 0 ||
      parsedReps > 100
    ) {
      setMessage("Enter a weight and whole-number reps.");
      return;
    }

    if (draft.sets.length >= 12) { setMessage("This workout has 12 sets. Finish it, then start another."); return; }
    const next: GuestDraft = {
      ...draft,
      stage: "moment",
      finishedAt: null,
      sets: [
        ...draft.sets,
        {
          id: setKey(),
          weight: parsedWeight,
          reps: parsedReps,
          exerciseName: draft.exercise.name,
          equipment: draft.exercise.equipment,
          ...(draft.exercise.exerciseId !== undefined ? { exerciseId: draft.exercise.exerciseId } : {}),
        },
      ],
    };
    setMessage(null);
    // Saving starts before the moment screen; it never waits on a network request.
    persist(next);
  };

  const logAnotherSet = () => {
    if (!draft) return;
    setWeight("");
    setReps("");
    setMessage(null);
    persist({ ...draft, stage: "log" });
  };

  const syncFinishedWorkout = (finished: GuestDraft) => {
    setSyncState("syncing");
    void syncGuestWorkout(finished)
      .then((synced) => {
        setSyncState("idle");
        // Do not replace a newer local continuation with a delayed sync response.
        if (draftRef.current?.finishedAt === finished.finishedAt) {
          persist(synced);
          return;
        }
        // A guest who chose Keep lifting while sync was pending starts fresh only after
        // their completed local workout has been safely synced.
        if (draftRef.current?.startedAt === finished.startedAt && draftRef.current.stage === "choose") {
          persist({ ...defaultGuestDraft(), unit: synced.unit, days: synced.days, stage: "choose" });
        }
      })
      .catch(() => {
        setSyncState("failed");
      });
  };

  const finish = () => {
    if (!draft) return;
    const finished: GuestDraft = { ...draft, stage: "finish", finishedAt: Date.now() };
    persist(finished);
    syncFinishedWorkout(finished);
  };

  const retrySync = () => {
    const current = draftRef.current;
    if (current?.stage === "finish") syncFinishedWorkout(current);
  };

  const keepLifting = async () => {
    if (!draft || syncState === "syncing") return;
    setMessage(null);
    if (draft.workoutId) {
      persist({ ...defaultGuestDraft(), unit: draft.unit, days: draft.days, stage: "choose" });
      return;
    }
    setSyncState("syncing");
    try {
      await syncGuestWorkout(draft);
      setSyncState("idle");
      persist({ ...defaultGuestDraft(), unit: draft.unit, days: draft.days, stage: "choose" });
    } catch { setSyncState("failed"); setMessage("Your set is still here. Connect to save it, then keep lifting."); }
  };

  const inviteFriend = async () => {
    setInvitePending(true);
    setMessage(null);
    try {
      await shareGuestInvite();
      setInviteComplete(true);
    } catch {
      setMessage("Couldn’t open sharing. Please try again.");
    } finally {
      setInvitePending(false);
    }
  };

  if (!draft) return <AppScreen scroll={false}><LoadingState /></AppScreen>;

  if (draft.stage === "welcome") {
    return <AppScreen contentStyle={styles.setupScreen}>
      <Text style={styles.welcomeTitle}>Hi. Let&apos;s get your first lift down.</Text>
      <View style={styles.questionGroup}>
        <Text style={styles.question}>Do you lift in lb or kg?</Text>
        <View style={styles.unitRow}>
          <ChoiceButton label="lb" selected={unitAnswered && draft.unit === "lb"} onPress={() => selectUnit("lb")} />
          <ChoiceButton label="kg" selected={unitAnswered && draft.unit === "kg"} onPress={() => selectUnit("kg")} />
        </View>
        <Pressable accessibilityRole="button" accessibilityLabel="Skip weight unit" onPress={() => selectUnit("lb")} style={styles.skipButton}><Text style={styles.skipText}>Skip</Text></Pressable>
      </View>
      <View style={styles.questionGroup}>
        <Text style={styles.question}>How many days a week would feel good?</Text>
        <View style={styles.daysRow}>{([2,3,4] as const).map((days) => <ChoiceButton key={days} label={String(days)} selected={draft.days === days} onPress={() => chooseDays(days)} style={styles.dayChoice} />)}</View>
        <Pressable accessibilityRole="button" accessibilityLabel="Skip weekly days" onPress={skipDays} style={styles.skipButton}><Text style={styles.skipText}>Skip</Text></Pressable>
      </View>
      <AppButton onPress={continueFromDays} disabled={!unitAnswered || !daysAnswered}>Continue</AppButton>
      <Pressable accessibilityRole="button" onPress={() => router.push("/auth" as never)} style={styles.signInButton}><Text style={styles.signInText}>Sign in</Text></Pressable>
    </AppScreen>;
  }

  if (draft.stage === "choose") {
    return (
      <AppScreen contentStyle={styles.screen}>
        <View style={styles.chooseHeader}>
          <Text style={styles.title}>What are you lifting today?</Text>
        </View>
        <View style={styles.tileGrid}>
          {EXERCISES.map((exercise) => (
            <Pressable
              key={exercise.name}
              accessibilityRole="button"
              accessibilityLabel={exercise.name}
              onPress={() => chooseExercise(exercise)}
              style={({ pressed }) => [styles.tile, pressed && styles.pressed]}
            >
              <Text style={styles.tileLabel}>{exercise.name}</Text>
            </Pressable>
          ))}
          <Pressable
            accessibilityRole="button"
            onPress={() => setCustomExercise(true)}
            style={({ pressed }) => [styles.tile, customExercise && styles.tileSelected, pressed && styles.pressed]}
          >
            <Text style={styles.tileLabel}>Something else</Text>
          </Pressable>
        </View>
        {customExercise ? (
          <View style={styles.customExercise}>
            <TextInput
              accessibilityLabel="Exercise name"
              autoFocus
              autoCapitalize="words"
              value={customName}
              onChangeText={setCustomName}
              placeholder="Exercise name"
              placeholderTextColor="#9AA69D"
              style={styles.customInput}
            />
            <AppButton onPress={continueWithCustomExercise} disabled={!customName.trim()}>Continue</AppButton>
          </View>
        ) : null}
        <AppButton variant="secondary" onPress={openTrainerPlan} disabled={planPending}>
          {planPending ? "Opening…" : "I have a plan from my trainer"}
        </AppButton>
        {message ? <Text style={styles.error}>{message}</Text> : null}
      </AppScreen>
    );
  }

  if (draft.stage === "log") {
    return (
      <AppScreen contentStyle={styles.logScreen}>
        <View style={styles.logFields}>
          <View style={styles.logField}>
            <Text style={styles.logLabel}>Weight</Text>
            <View style={styles.valueRow}>
              <NumberInput
                accessibilityLabel={`Weight in ${draft.unit}`}
                value={weight}
                onChangeText={setWeight}
                placeholder=""
                placeholderTextColor="#AAB5AD"
                style={styles.bigInput}
              />
              <Text style={styles.unitText}>{draft.unit}</Text>
            </View>
          </View>
          <View style={styles.logField}>
            <Text style={styles.logLabel}>Reps</Text>
            <NumberInput
              accessibilityLabel="Reps"
              keyboardType="number-pad"
              value={reps}
              onChangeText={setReps}
              placeholder=""
              placeholderTextColor="#AAB5AD"
              style={styles.bigInput}
            />
          </View>
        </View>
        <View style={styles.logAction}>
          {message ? <Text style={styles.error}>{message}</Text> : null}
          <AppButton onPress={logSet}>Log set</AppButton>
        </View>
      </AppScreen>
    );
  }

  if (draft.stage === "moment") {
    const loggedSet = draft.sets[draft.sets.length - 1];
    if (!loggedSet) return null;
    const firstSet = draft.sets.length === 1;
    const bestSet = draft.sets.filter((set) => set.exerciseName === loggedSet.exerciseName && set.equipment === loggedSet.equipment).reduce((best, current) => (current.weight > best.weight ? current : best), loggedSet);
    return (
      <FirstLiftMoment
        firstSet={firstSet}
        line={setLine(loggedSet, draft.unit)}
        bestLine={setLine(bestSet, draft.unit)}
        onAnother={logAnotherSet}
        onFinish={finish}
      />
    );
  }

  const weekStarted = draft.days === null ? "Week 1 has started." : `Week 1 has started: 1 of ${draft.days}.`;
  return (
    <AppScreen scroll={false} contentStyle={styles.finishScreen}>
      <View style={styles.finishTop}>
        <Text style={styles.finishTitle}>{weekStarted}</Text>
        <Card style={styles.inviteCard}>
          <Text style={styles.inviteText}>Lifting is easier when one person notices.</Text>
          <AppButton onPress={inviteFriend} disabled={invitePending}>
            {invitePending ? "Opening…" : inviteComplete ? "Invite copied" : "Invite a friend"}
          </AppButton>
          <AppButton variant="ghost" onPress={() => router.push("/auth?saveLifts=1" as never)}>Not now</AppButton>
        </Card>
        {inviteComplete ? <AppButton variant="secondary" onPress={() => router.push("/auth?saveLifts=1" as never)}>Save your lifts</AppButton> : null}
        {syncState === "failed" ? (
          <View style={styles.syncRow}>
            <Text style={styles.syncError}>Couldn&apos;t sync yet.</Text>
            <Pressable accessibilityRole="button" onPress={retrySync} style={styles.retryButton}>
              <Text style={styles.retryText}>Retry sync</Text>
            </Pressable>
          </View>
        ) : null}
        {message ? <Text style={styles.error}>{message}</Text> : null}
      </View>
      <View style={styles.finishActions}>
        <AppButton variant="secondary" disabled={syncState === "syncing"} onPress={() => void keepLifting()}>Keep lifting</AppButton>
      </View>
    </AppScreen>
  );
}

function ChoiceButton({ label, selected, onPress, style }: { label: string; selected: boolean; onPress: () => void; style?: object }) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={({ pressed }) => [styles.choice, selected && styles.choiceSelected, pressed && styles.pressed, style]}
    >
      <Text style={[styles.choiceText, selected && styles.choiceTextSelected]}>{label}</Text>
    </Pressable>
  );
}

export default FirstLift;

const styles = StyleSheet.create({
  setupScreen: {flexGrow:1,justifyContent:"center",gap:22,paddingHorizontal:20,paddingVertical:24},
  centeredScreen: { flex: 1, paddingHorizontal: 20, paddingVertical: 24 },
  welcomeContent: { flex: 1, width: "100%", maxWidth: 520, alignSelf: "center", justifyContent: "center", gap: 40 },
  welcomeTitle: { color: colors.ink, fontSize: 31, fontWeight: "800", letterSpacing: -1, lineHeight: 38 },
  questionGroup: { gap: 14 },
  question: { color: colors.ink, fontSize: 20, fontWeight: "800", letterSpacing: -0.35, lineHeight: 26 },
  unitRow: { flexDirection: "row", gap: 12 },
  daysRow: { flexDirection: "row", gap: 10 },
  choice: { flex: 1, minHeight: 74, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.line, borderRadius: 18, backgroundColor: colors.panel, paddingHorizontal: 12 },
  dayChoice: { minHeight: 84 },
  choiceSelected: { borderColor: colors.limeDark, backgroundColor: colors.paleLime },
  choiceText: { color: colors.ink, fontSize: 22, fontWeight: "800", letterSpacing: -0.5 },
  choiceTextSelected: { color: colors.limeDark },
  skipButton: { minHeight: 44, alignSelf: "flex-start", justifyContent: "center", paddingHorizontal: 2 },
  skipText: { color: colors.limeDark, fontSize: 16, fontWeight: "800" },
  disclosure: { color: colors.muted, fontSize: 16, lineHeight: 20, marginTop: -4 },
  signInButton: { minHeight: 44, alignSelf: "flex-start", justifyContent: "center", paddingHorizontal: 2, marginTop: 2 },
  signInText: { color: colors.muted, fontSize: 16, fontWeight: "700" },
  screen: { gap: 16, paddingTop: 24, paddingBottom: 28 },
  chooseHeader: { marginBottom: 2 },
  title: { color: colors.ink, fontSize: 31, fontWeight: "800", letterSpacing: -1, lineHeight: 38 },
  tileGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  tile: { width: "48%", minHeight: 72, justifyContent: "center", borderWidth: 1, borderColor: colors.line, borderRadius: 17, backgroundColor: colors.panel, paddingHorizontal: 14 },
  tileSelected: { borderColor: colors.limeDark, backgroundColor: colors.paleLime },
  tileLabel: { color: colors.ink, fontSize: 16, fontWeight: "800", lineHeight: 20 },
  customExercise: { gap: 10 },
  customInput: { minHeight: 52, borderWidth: 1, borderColor: colors.line, borderRadius: 15, backgroundColor: colors.panel, color: colors.ink, fontSize: 16, fontWeight: "600", paddingHorizontal: 15 },
  pressed: { opacity: 0.76, transform: [{ scale: 0.985 }] },
  error: { color: colors.rust, fontSize: 16, fontWeight: "700", lineHeight: 22 },
  logScreen: { flexGrow: 1, justifyContent: "space-between", paddingHorizontal: 20, paddingTop: 36, paddingBottom: 28, gap: 28 },
  logFields: { gap: 28 },
  logField: { gap: 10 },
  logLabel: { color: colors.ink, fontSize: 40, fontWeight: "800", letterSpacing: -1.4, lineHeight: 46 },
  valueRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  bigInput: { flex: 1, minWidth: 0, width: "100%", minHeight: 74, borderWidth: 1, borderColor: colors.line, borderRadius: 18, backgroundColor: colors.panel, color: colors.ink, fontSize: 30, fontWeight: "800", paddingHorizontal: 18 },
  unitText: { color: colors.muted, fontSize: 20, fontWeight: "800", minWidth: 28 },
  logAction: { gap: 12 },
  finishScreen: { flex: 1, justifyContent: "space-between", paddingHorizontal: 20, paddingTop: 38, paddingBottom: 26, gap: 24 },
  finishTop: { gap: 24, width: "100%", maxWidth: 520, alignSelf: "center" },
  finishTitle: { color: colors.ink, fontSize: 31, fontWeight: "800", letterSpacing: -1, lineHeight: 38 },
  inviteCard: { gap: 18, padding: 20 },
  inviteText: { color: colors.ink, fontSize: 20, fontWeight: "800", letterSpacing: -0.35, lineHeight: 27 },
  finishActions: { width: "100%", maxWidth: 520, alignSelf: "center", gap: 4 },
  syncRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  syncError: { color: colors.muted, fontSize: 16, flex: 1 },
  retryButton: { minHeight: 44, justifyContent: "center", paddingHorizontal: 4 },
  retryText: { color: colors.limeDark, fontSize: 16, fontWeight: "800" },
});
