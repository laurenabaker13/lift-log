import { AuthGate } from "@/components/lift-log/auth-gate";
import { NextWeightLine } from "@/components/lift-log/next-weight-line";
import { ProgressTrend } from "@/components/lift-log/progress-trend";
import { AppScreen, Card, colors, ui } from "@/components/lift-log/ui";
import { trpc } from "@/lib/trpc";
import { getNextWeight } from "@/shared/next-weight";
import { progressSummary } from "@/shared/progress";
import { formatWeight } from "@/shared/strength";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

type HistoryEntry = {
  workoutId: number;
  performedAt: Date | string;
  setNumber: number;
  actualWeight: number;
  actualReps: number;
  rpe: number | null;
  estimatedOneRepMax: number | null;
};

function groupHistoryByWorkout(history: HistoryEntry[]) {
  const groups = new Map<
    number,
    { workoutId: number; performedAt: Date; sets: HistoryEntry[] }
  >();
  for (const entry of history) {
    const performedAt = new Date(entry.performedAt);
    const group = groups.get(entry.workoutId);
    if (group) group.sets.push(entry);
    else
      groups.set(entry.workoutId, {
        workoutId: entry.workoutId,
        performedAt,
        sets: [entry],
      });
  }
  return Array.from(groups.values())
    .map((group) => ({
      ...group,
      sets: [...group.sets].sort((a, b) => a.setNumber - b.setNumber),
    }))
    .sort(
      (a, b) =>
        b.performedAt.getTime() - a.performedAt.getTime() ||
        b.workoutId - a.workoutId,
    );
}

function ExerciseDetail() {
  const router = useRouter();
  const params = useLocalSearchParams<{ id: string }>();
  const exerciseId = Number(params.id);
  const progress = trpc.progress.list.useQuery();
  const settings = trpc.settings.get.useQuery();
  const [historyOpen, setHistoryOpen] = useState(false);
  const unit = settings.data?.unit ?? "lb";

  if (progress.isLoading) {
    return (
      <AppScreen>
        <Text style={styles.loading}>Loading history…</Text>
      </AppScreen>
    );
  }

  const item = progress.data?.find((entry) => entry.exerciseId === exerciseId);
  if (!item) {
    return (
      <AppScreen>
        <View style={styles.empty}>
          <Text style={styles.emptyText}>
            There is no saved history for this exercise yet.
          </Text>
          <Pressable
            accessibilityRole="button"
            onPress={() => router.push("/workout/new" as never)}
            style={({ pressed }) => [
              styles.startButton,
              pressed && styles.pressed,
            ]}
          >
            <Text style={styles.startButtonText}>Start workout</Text>
          </Pressable>
        </View>
      </AppScreen>
    );
  }

  const history = item.history as HistoryEntry[];
  const summary = progressSummary(history);
  const suggestion = getNextWeight(history, item.name, unit);
  const dateGroups = groupHistoryByWorkout(history);

  return (
    <AppScreen>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Back to progress"
        onPress={() => router.back()}
        style={({ pressed }) => [styles.back, pressed && styles.pressed]}
      >
        <Text style={styles.backText}>‹ Back to progress</Text>
      </Pressable>

      <View style={styles.header}>
        <Text style={ui.title}>{item.name}</Text>
        <Text style={styles.equipment}>{item.equipment}</Text>
      </View>

      {summary.best === null ? (
        <Card style={styles.bodyweightCard}>
          <Text style={styles.bestLabel}>Best lift</Text>
          <Text style={styles.bodyweightValue}>Bodyweight</Text>
          <Text style={styles.note}>
            This exercise uses your body instead of added weight.
          </Text>
        </Card>
      ) : (
        <ProgressTrend history={history} unit={unit} />
      )}

      {suggestion ? (
        <NextWeightLine
          suggestion={suggestion}
          unit={unit}
          onUse={() =>
            router.push(
              `/workout/new?exerciseId=${item.exerciseId}&suggestedWeight=${suggestion.weight}&suggestedReps=${suggestion.lastReps}` as never,
            )
          }
        />
      ) : null}

      <View style={styles.historySection}>
        <Pressable
          accessibilityRole="button"
          accessibilityState={{ expanded: historyOpen }}
          onPress={() => setHistoryOpen((open) => !open)}
          style={({ pressed }) => [
            styles.historyToggle,
            pressed && styles.pressed,
          ]}
        >
          <Text style={styles.historyTitle}>History</Text>
          <Text style={styles.historyToggleText}>
            {historyOpen ? "Hide" : "Show"}
          </Text>
        </Pressable>

        {historyOpen
          ? dateGroups.map((session) => (
              <Card key={session.workoutId} style={styles.historyCard}>
                <Text style={styles.date}>
                  {new Intl.DateTimeFormat(undefined, {
                    month: "short",
                    day: "numeric",
                    year: "numeric",
                  }).format(session.performedAt)}
                </Text>
                {session.sets.map((entry) => (
                  <Text
                    key={`${entry.workoutId}-${entry.setNumber}`}
                    style={styles.setText}
                  >
                    Set {entry.setNumber + 1} ·{" "}
                    {entry.actualWeight === 0
                      ? `Bodyweight × ${entry.actualReps}`
                      : `${formatWeight(entry.actualWeight, unit)} × ${entry.actualReps}`}
                  </Text>
                ))}
              </Card>
            ))
          : null}
      </View>
    </AppScreen>
  );
}

export default function ExerciseDetailScreen() {
  return (
    <AuthGate>
      <ExerciseDetail />
    </AuthGate>
  );
}

const styles = StyleSheet.create({
  back: { minHeight: 44, alignSelf: "flex-start", justifyContent: "center" },
  backText: { color: colors.limeDark, fontSize: 16, fontWeight: "800" },
  header: { gap: 5 },
  equipment: { color: colors.muted, fontSize: 16, lineHeight: 23 },
  loading: { color: colors.muted, fontSize: 16, lineHeight: 23 },
  empty: { gap: 14, alignItems: "flex-start" },
  emptyText: { color: colors.muted, fontSize: 16, lineHeight: 23 },
  startButton: {
    minHeight: 44,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 14,
    backgroundColor: colors.ink,
    paddingHorizontal: 18,
  },
  startButtonText: { color: colors.panel, fontSize: 16, fontWeight: "800" },
  bodyweightCard: {
    gap: 7,
    backgroundColor: colors.paleLime,
    borderColor: "#DCEAB4",
  },
  bestLabel: { color: colors.ink, fontSize: 18, fontWeight: "800" },
  bodyweightValue: {
    color: colors.limeDark,
    fontSize: 30,
    fontWeight: "800",
    letterSpacing: -0.8,
    lineHeight: 35,
  },
  note: { color: colors.limeDark, fontSize: 16, lineHeight: 22 },
  historySection: { gap: 10 },
  historyToggle: {
    minHeight: 44,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  historyTitle: { color: colors.ink, fontSize: 18, fontWeight: "800" },
  historyToggleText: {
    color: colors.limeDark,
    fontSize: 16,
    fontWeight: "800",
    textDecorationLine: "underline",
  },
  historyCard: { gap: 10 },
  date: { color: colors.ink, fontSize: 16, fontWeight: "800", lineHeight: 22 },
  setText: {
    color: colors.muted,
    fontSize: 16,
    lineHeight: 23,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.line,
    paddingTop: 10,
  },
  pressed: { opacity: 0.72 },
});
