import * as Api from "@/lib/_core/api";
import { AppButton, AppScreen, BrandMark, Card, colors, ui } from "@/components/lift-log/ui";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useState } from "react";
import { StyleSheet, Text, View } from "react-native";

export default function VerifyEmailScreen() {
  const router = useRouter();
  const { token } = useLocalSearchParams<{ token?: string }>();
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  const validToken = typeof token === "string" && token.length > 20;
  const verify = async () => {
    if (!validToken) return setError("This verification link is invalid. Request a new one from Settings.");
    setPending(true); setError(null);
    try { const result = await Api.verifyEmail(token); setMessage(result.message); } catch (caught) { setError(caught instanceof Error ? caught.message : "We couldn’t verify your email. Try again."); } finally { setPending(false); }
  };
  return <AppScreen contentStyle={styles.screen}><View style={styles.hero}><BrandMark /><Text style={ui.title}>Verify your email</Text><Text style={ui.subtitle}>We’ll use this email for account recovery and coach invitations.</Text></View><Card style={styles.card}>{message ? <Text style={styles.success}>{message}</Text> : null}{error ? <Text style={styles.error}>{error}</Text> : null}<AppButton onPress={verify} disabled={pending || !validToken}>{pending ? "Verifying…" : "Verify email"}</AppButton><AppButton variant="secondary" onPress={() => router.replace("/" as never)}>Go to Lift Log</AppButton></Card></AppScreen>;
}
const styles = StyleSheet.create({ screen: { justifyContent: "center", gap: 22 }, hero: { gap: 9 }, card: { gap: 14 }, error: { color: colors.rust, fontSize: 16, fontWeight: "700", lineHeight: 19 }, success: { color: colors.limeDark, fontSize: 16, fontWeight: "700", lineHeight: 19 } });
