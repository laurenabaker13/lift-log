import { AuthGate } from "@/components/lift-log/auth-gate";
import { EquipmentPicker } from "@/components/lift-log/equipment-picker";
import { ScreenTip } from "@/components/lift-log/interactive-tour";
import { NumberInput } from "@/components/lift-log/number-input";
import { WeightInput } from "@/components/lift-log/weight-input";
import {
  AppButton,
  AppInput,
  AppScreen,
  Card,
  LoadingState,
  colors,
  ui,
} from "@/components/lift-log/ui";
import { trpc } from "@/lib/trpc";
import { NextWeightLine } from "@/components/lift-log/next-weight-line";
import { getNextWeight } from "@/shared/next-weight";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useMemo, useState } from "react";
import {
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  View,
} from "react-native";

type SetEntry = {
  key: string;
  targetReps: number;
  actualWeight: number | null;
  actualReps: number | null;
  rpe: number | null;
};
type ExerciseEntry = {
  key: string;
  exerciseId: number;
  name: string;
  equipment: string;
  plannedPercent: number | null;
  plannedWeight: number | null;
  targetRpe: number | null;
  sets: SetEntry[];
};
type Draft = {
  name: string;
  notes: string;
  isPrivate: boolean;
  exercises: ExerciseEntry[];
};
const key = () => Math.random().toString(36).slice(2);
const emptyDraft = (): Draft => ({
  name: "Workout",
  notes: "",
  isPrivate: false,
  exercises: [],
});
function fromWorkout(workout: any): Draft {
  return {
    name: workout.name,
    notes: workout.notes ?? "",
    isPrivate: Boolean(workout.isPrivate),
    exercises: workout.exercises.map((entry: any) => ({
      ...entry,
      key: key(),
      name: entry.exercise.name,
      equipment: entry.exercise.equipment,
      sets: entry.sets.map((set: any) => ({
        ...set,
        key: key(),
        actualReps: set.actualReps ?? set.targetReps,
      })),
    })),
  };
}
function WorkoutEditor() {
  const router = useRouter();
  const {
    id,
    exerciseId: seedId,
    suggestedWeight: seedWeight,
    suggestedReps: seedReps,
  } = useLocalSearchParams<{
    id: string;
    exerciseId?: string;
    suggestedWeight?: string;
    suggestedReps?: string;
  }>();
  const [startedAt] = useState(() => Date.now());
  const isNew = id === "new";
  const workoutId = Number(id);
  const utils = trpc.useUtils();
  const workout = trpc.workout.get.useQuery(
    { id: workoutId },
    { enabled: !isNew && workoutId > 0 },
  );
  const catalog = trpc.exercise.list.useQuery();
  const progress = trpc.progress.list.useQuery();
  const settings = trpc.settings.get.useQuery();
  const friends = trpc.friends.hub.useQuery();
  const [override, setOverride] = useState<Draft | null>(null);
  const base = useMemo(() => {
    if (!isNew) return workout.data ? fromWorkout(workout.data) : null;
    const d = emptyDraft();
    const selected = catalog.data?.find((ex) => ex.id === Number(seedId));
    if (
      selected &&
      seedWeight !== undefined &&
      Number.isFinite(Number(seedWeight)) &&
      Number(seedWeight) >= 0
    ) {
      const reps = Math.max(
        1,
        Math.min(100, Math.floor(Number(seedReps) || 8)),
      );
      d.exercises = [
        {
          key: `seed-${selected.id}`,
          exerciseId: selected.id,
          name: selected.name,
          equipment: selected.equipment,
          plannedPercent: null,
          plannedWeight: null,
          targetRpe: null,
          sets: [
            {
              key: "seed-set",
              targetReps: reps,
              actualWeight: Number(seedWeight),
              actualReps: reps,
              rpe: null,
            },
          ],
        },
      ];
    }
    return d;
  }, [isNew, workout.data, catalog.data, seedId, seedWeight, seedReps]);
  const draft = override ?? base;
  const update = (fn: (draft: Draft) => Draft) =>
    setOverride((current) => {
      const d = current ?? base;
      return d ? fn(d) : null;
    });
  const [picker, setPicker] = useState(false);
  const [search, setSearch] = useState("");
  const [customName, setCustomName] = useState("");
  const [customEquipment, setCustomEquipment] = useState("Barbell");
  const [message, setMessage] = useState("");
  const [cancelOpen, setCancelOpen] = useState(false);
  const [createdId, setCreatedId] = useState<number | null>(null);
  const [templateName, setTemplateName] = useState("");
  const template = trpc.template.create.useMutation();
  const [saving, setSaving] = useState(false);
  const [shareOverride, setShareOverride] = useState<boolean | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const create = trpc.workout.createFromPlan.useMutation();
  const save = trpc.workout.save.useMutation();
  const remove = trpc.workout.delete.useMutation();
  const variant = trpc.exercise.getOrCreateVariant.useMutation();
  const custom = trpc.exercise.createCustom.useMutation();
  const hasFriends = Boolean(friends.data?.friends.length);
  const share =
    hasFriends &&
    (shareOverride ??
      (Boolean(settings.data?.shareFriendActivity) && !draft?.isPrivate));
  const unit = settings.data?.unit ?? "lb";
  const changeExercise = (
    exerciseKey: string,
    change: Partial<ExerciseEntry>,
  ) =>
    update((d) => ({
      ...d,
      exercises: d.exercises.map((ex) =>
        ex.key === exerciseKey ? { ...ex, ...change } : ex,
      ),
    }));
  const changeSet = (
    exerciseKey: string,
    setKey: string,
    change: Partial<SetEntry>,
  ) =>
    update((d) => ({
      ...d,
      exercises: d.exercises.map((ex) =>
        ex.key === exerciseKey
          ? {
              ...ex,
              sets: ex.sets.map((set) =>
                set.key === setKey ? { ...set, ...change } : set,
              ),
            }
          : ex,
      ),
    }));
  const addExercise = (exercise: {
    id: number;
    name: string;
    equipment: string;
  }) => {
    update((d) => ({
      ...d,
      exercises: [
        ...d.exercises,
        {
          key: key(),
          exerciseId: exercise.id,
          name: exercise.name,
          equipment: exercise.equipment,
          plannedPercent: null,
          plannedWeight: null,
          targetRpe: 7,
          sets: [
            {
              key: key(),
              targetReps: 8,
              actualWeight: null,
              actualReps: 8,
              rpe: null,
            },
          ],
        },
      ],
    }));
    setPicker(false);
    setSearch("");
  };
  const finish = async () => {
    if (!draft || saving) return;
    if (!draft.exercises.length) {
      setMessage("Add an exercise first.");
      return;
    }
    if (
      draft.exercises.some(
        (ex) =>
          !ex.sets.length ||
          ex.sets.some(
            (set) =>
              set.actualWeight === null ||
              set.actualWeight < 0 ||
              !set.actualReps ||
              !Number.isInteger(set.actualReps),
          ),
      )
    ) {
      setMessage(
        "Enter a weight and whole-number reps for every set. Use 0 for bodyweight.",
      );
      return;
    }
    setSaving(true);
    setMessage("");
    const input = {
      name: draft.name.trim() || "Workout",
      notes: draft.notes || null,
      isPrivate: !share,
      durationSeconds: workout.data?.completedAt
        ? (workout.data.durationSeconds ?? undefined)
        : Math.min(
            604800,
            Math.max(0, Math.floor((Date.now() - startedAt) / 1000)),
          ),
      exercises: draft.exercises.map((ex) => ({
        exerciseId: ex.exerciseId,
        plannedPercent: ex.plannedPercent,
        plannedWeight: ex.plannedWeight,
        targetRpe: ex.targetRpe,
        sets: ex.sets.map((set) => ({
          targetReps: set.actualReps ?? set.targetReps,
          actualReps: set.actualReps,
          actualWeight: set.actualWeight,
          rpe: set.rpe,
        })),
      })),
    };
    try {
      const created =
        isNew && !createdId ? await create.mutateAsync(input) : null;
      const savedId = created?.id ?? createdId ?? workoutId;
      if (created?.id) setCreatedId(created.id);
      await save.mutateAsync({ ...input, id: savedId, completed: true });
      await Promise.all([
        utils.workout.listRecent.invalidate(),
        utils.progress.list.invalidate(),
        utils.program.getActive.invalidate(),
        utils.friends.hub.invalidate(),
      ]);
      router.replace(
        (workout.data?.completedAt ? "/" : `/finish/${savedId}`) as never,
      );
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Could not save. Your entries are still here—try again.",
      );
    } finally {
      setSaving(false);
    }
  };
  if (!draft)
    return (
      <AppScreen>
        <LoadingState
          label={workout.error ? workout.error.message : "Opening workout…"}
        />
      </AppScreen>
    );
  return (
    <View style={{ flex: 1 }}>
      <AppScreen>
        <View style={styles.header}>
          <Text style={ui.title}>
            {workout.data?.completedAt ? "Edit workout" : "Your workout"}
          </Text>
          <AppButton variant="ghost" onPress={() => setCancelOpen(true)}>
            Close
          </AppButton>
        </View>
        <ScreenTip area="workout" />
        {message ? (
          <Text accessibilityRole="alert" style={styles.error}>
            {message}
          </Text>
        ) : null}
        {draft.exercises.length === 0 ? (
          <Card style={{ gap: 8 }}>
            <Text style={ui.mutedText}>What are you lifting today?</Text>
            <AppButton onPress={() => setPicker(true)}>Add exercise</AppButton>
          </Card>
        ) : null}
        {draft.exercises.map((ex) => {
          const current = progress.data?.find(
            (item) => item.exerciseId === ex.exerciseId,
          );
          const hint = getNextWeight(current?.history ?? [], ex.name, unit);
          const effort = ex.sets[0]?.rpe;
          const planned = workout.data?.programWorkoutId && !workout.data.completedAt
            ? base?.exercises.find((entry) => entry.key === ex.key)
            : null;
          const plannedReps = planned?.sets.map((set) => set.targetReps) ?? [];
          const planLine = planned ? [
            planned.sets.length ? `${planned.sets.length} ${planned.sets.length === 1 ? "set" : "sets"}` : "",
            plannedReps.length && plannedReps.every((reps) => reps > 0)
              ? `x ${plannedReps.every((reps) => reps === plannedReps[0]) ? plannedReps[0] : plannedReps.join(" / ")} reps`
              : "",
            planned.plannedWeight !== null && planned.plannedWeight !== undefined
              ? `at ${Number(planned.plannedWeight.toFixed(4))} ${unit}`
              : "",
          ].filter(Boolean).join(" ") : "";
          return (
            <Card key={ex.key} style={{ gap: 12 }}>
              <View style={styles.header}>
                <View style={ui.grow}>
                  <Text style={styles.exercise}>{ex.name}</Text>
                </View>
                <AppButton
                  variant="ghost"
                  onPress={() =>
                    update((d) => ({
                      ...d,
                      exercises: d.exercises.filter((e) => e.key !== ex.key),
                    }))
                  }
                >
                  Remove
                </AppButton>
              </View>
              <EquipmentPicker
                value={ex.equipment}
                disabled={variant.isPending}
                onChange={async (equipment) => {
                  try {
                    const result = await variant.mutateAsync({
                      sourceExerciseId: ex.exerciseId,
                      equipment,
                    });
                    changeExercise(ex.key, {
                      exerciseId: result.id,
                      equipment: result.equipment,
                      name: result.name,
                      plannedWeight: null,
                    });
                    await utils.exercise.list.invalidate();
                  } catch (e) {
                    setMessage(
                      e instanceof Error
                        ? e.message
                        : "Could not change equipment.",
                    );
                  }
                }}
              />
              {!workout.data?.completedAt ? <NextWeightLine
                suggestion={hint}
                unit={unit}
                onUse={() => {
                  if (!hint || !ex.sets[0]) return;
                  changeSet(ex.key, ex.sets[0].key, {
                    actualWeight: hint.weight,
                  });
                }}
              /> : null}
              {planLine ? (
                <Text style={styles.last}>
                  Plan: {planLine}{planned?.equipment ? ` · ${planned.equipment}` : ""}
                </Text>
              ) : null}
              {ex.sets.map((set, index) => (
                <View key={set.key} style={styles.set}>
                  <View style={styles.header}>
                    <Text style={styles.setLabel}>Set {index + 1}</Text>
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel={`Remove set ${index + 1}`}
                      style={styles.remove}
                      onPress={() =>
                        changeExercise(ex.key, {
                          sets: ex.sets.filter((s) => s.key !== set.key),
                        })
                      }
                    >
                      <Text style={ui.link}>Remove</Text>
                    </Pressable>
                  </View>
                  <View style={styles.fields}>
                    <View style={styles.weight}>
                      <WeightInput
                        label={`Weight (${unit})`}
                        unit={unit}
                        value={set.actualWeight}
                        onChange={(actualWeight) =>
                          changeSet(ex.key, set.key, { actualWeight })
                        }
                      />
                    </View>
                    <View style={styles.reps}>
                      <Text style={styles.setLabel}>Reps</Text>
                      <NumberInput
                        accessibilityLabel={`Set ${index + 1} reps`}
                        keyboardType="decimal-pad"
                        value={
                          set.actualReps === null ? "" : String(set.actualReps)
                        }
                        onChangeText={(text) =>
                          changeSet(ex.key, set.key, {
                            actualReps: text ? Number(text) : null,
                          })
                        }
                        style={styles.repsInput}
                      />
                    </View>
                  </View>
                </View>
              ))}
              <AppButton
                variant="secondary"
                onPress={() => {
                  const previous = ex.sets.at(-1);
                  changeExercise(ex.key, {
                    sets: [
                      ...ex.sets,
                      {
                        key: key(),
                        targetReps: previous?.actualReps ?? 8,
                        actualReps: previous?.actualReps ?? 8,
                        actualWeight: previous?.actualWeight ?? null,
                        rpe: null,
                      },
                    ],
                  });
                }}
              >
                Add set
              </AppButton>
              <Text style={styles.setLabel}>
                How did that feel?{" "}
                <Text style={styles.optional}>(optional)</Text>
              </Text>
              <View style={styles.feelings}>
                {[
                  { label: "Easy", value: 6 },
                  { label: "Good", value: 8 },
                  { label: "Hard", value: 10 },
                ].map((feeling) => (
                  <AppButton
                    key={feeling.label}
                    style={{ flex: 1, paddingHorizontal: 3 }}
                    variant={effort === feeling.value ? "primary" : "secondary"}
                    onPress={() =>
                      changeExercise(ex.key, {
                        sets: ex.sets.map((set) => ({
                          ...set,
                          rpe: effort === feeling.value ? null : feeling.value,
                        })),
                      })
                    }
                  >
                    {feeling.label}
                  </AppButton>
                ))}
              </View>
            </Card>
          );
        })}
        {draft.exercises.length ? (
          <AppButton variant="secondary" onPress={() => setPicker(true)}>
            Add exercise
          </AppButton>
        ) : null}
        <AppButton variant="ghost" onPress={() => setDetailsOpen(!detailsOpen)}>
          {detailsOpen ? "Hide workout details" : "Workout details"}
        </AppButton>
        {detailsOpen ? (
          <Card style={{ gap: 12 }}>
            <AppInput
              label="Workout name"
              value={draft.name}
              onChangeText={(name) => update((d) => ({ ...d, name }))}
            />
            <AppInput
              label="Notes (optional)"
              value={draft.notes}
              onChangeText={(notes) => update((d) => ({ ...d, notes }))}
            />
            <AppInput
              label="Template name (optional)"
              value={templateName}
              onChangeText={setTemplateName}
            />
            <AppButton
              variant="secondary"
              disabled={
                !templateName.trim() ||
                !draft.exercises.length ||
                template.isPending
              }
              onPress={async () => {
                try {
                  await template.mutateAsync({
                    name: templateName.trim(),
                    exercises: draft.exercises.map((ex) => ({
                      exerciseId: ex.exerciseId,
                      sets: ex.sets.map((set) => ({
                        targetReps: set.actualReps ?? set.targetReps,
                      })),
                    })),
                  });
                  await utils.template.list.invalidate();
                  setMessage("Template saved.");
                } catch (error) {
                  setMessage(
                    error instanceof Error
                      ? error.message
                      : "Could not save template.",
                  );
                }
              }}
            >
              Save template
            </AppButton>
            <View style={styles.header}>
              <Text style={styles.setLabel}>
                Share with friends · {share ? "On" : "Off"}
              </Text>
              <Switch
                accessibilityLabel="Share with friends"
                value={share}
                disabled={!hasFriends}
                onValueChange={(value) => setShareOverride(value)}
              />
            </View>
            <Text style={styles.last}>
              {share
                ? "Friends can see this completed workout and any best lifts."
                : "This workout stays private."}
              {!hasFriends ? " Add a friend to turn sharing on." : ""}
            </Text>
          </Card>
        ) : null}
      </AppScreen>
      <View style={styles.footer}>
        <AppButton
          onPress={finish}
          disabled={saving || !draft.exercises.length}
        >
          {saving
            ? "Saving…"
            : workout.data?.completedAt
              ? "Save workout"
              : "Finish workout"}
        </AppButton>
      </View>
      <Modal
        visible={picker}
        transparent
        animationType="slide"
        onRequestClose={() => setPicker(false)}
      >
        <View style={styles.shade}>
          <View style={styles.modal}>
            <View style={styles.header}>
              <Text style={styles.exercise}>Add exercise</Text>
              <AppButton variant="ghost" onPress={() => setPicker(false)}>
                Close
              </AppButton>
            </View>
            <AppInput
              accessibilityLabel="Search exercises"
              value={search}
              onChangeText={setSearch}
              placeholder="Search exercises"
            />
            <ScrollView
              keyboardShouldPersistTaps="handled"
              style={{ maxHeight: 280 }}
            >
              {catalog.data
                ?.filter((ex) =>
                  `${ex.name} ${ex.equipment}`
                    .toLowerCase()
                    .includes(search.toLowerCase()),
                )
                .map((ex) => (
                  <Pressable
                    accessibilityRole="button"
                    key={ex.id}
                    style={styles.catalogItem}
                    onPress={() => addExercise(ex)}
                  >
                    <Text style={styles.setLabel}>{ex.name}</Text>
                    <Text style={styles.last}>{ex.equipment}</Text>
                  </Pressable>
                ))}
            </ScrollView>
            <AppInput
              label="Or add your own exercise"
              value={customName}
              onChangeText={setCustomName}
              placeholder="Exercise name"
            />
            <EquipmentPicker
              value={customEquipment}
              onChange={setCustomEquipment}
            />
            <AppButton
              variant="secondary"
              disabled={!customName.trim() || custom.isPending}
              onPress={async () => {
                try {
                  const exercise = await custom.mutateAsync({
                    name: customName,
                    equipment: customEquipment,
                  });
                  addExercise(exercise);
                  setCustomName("");
                  await utils.exercise.list.invalidate();
                } catch (error) {
                  setMessage(
                    error instanceof Error
                      ? error.message
                      : "Could not add exercise.",
                  );
                }
              }}
            >
              Add custom exercise
            </AppButton>
          </View>
        </View>
      </Modal>
      <Modal
        visible={cancelOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setCancelOpen(false)}
      >
        <View style={[styles.shade, { justifyContent: "center", padding: 20 }]}>
          <Card style={{ gap: 12 }}>
            <Text style={styles.exercise}>Close this workout?</Text>
            <Text style={ui.mutedText}>
              Changes you haven’t saved will be lost. Your completed workouts
              stay saved.
            </Text>
            <AppButton variant="secondary" onPress={() => setCancelOpen(false)}>
              Keep editing
            </AppButton>
            <AppButton
              variant="danger"
              onPress={async () => {
                if (!isNew && !workout.data?.completedAt)
                  await remove.mutateAsync({ id: workoutId });
                await utils.workout.listRecent.invalidate();
                router.replace("/" as never);
              }}
            >
              Discard changes
            </AppButton>
          </Card>
        </View>
      </Modal>
    </View>
  );
}
export default function WorkoutScreen() {
  return (
    <AuthGate>
      <WorkoutEditor />
    </AuthGate>
  );
}
const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
  },
  exercise: { color: colors.ink, fontSize: 20, fontWeight: "800" },
  last: { color: colors.muted, fontSize: 16, lineHeight: 24 },
  set: { gap: 7, borderTopWidth: 1, borderColor: colors.line, paddingTop: 7 },
  setLabel: { color: colors.ink, fontSize: 16, fontWeight: "700" },
  remove: { minHeight: 44, justifyContent: "center", paddingHorizontal: 8 },
  fields: { flexDirection: "row", gap: 10, alignItems: "flex-start" },
  weight: { flex: 1, minWidth: 0 },
  reps: { width: 65, gap: 7 },
  repsInput: {
    minHeight: 50,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: colors.line,
    textAlign: "center",
    fontSize: 18,
    color: colors.ink,
    backgroundColor: colors.bone,
  },
  feelings: { flexDirection: "row", gap: 7 },
  optional: { color: colors.muted, fontWeight: "400" },
  footer: {
    padding: 12,
    backgroundColor: colors.panel,
    borderTopWidth: 1,
    borderColor: colors.line,
  },
  error: { color: colors.rust, fontSize: 16 },
  shade: {
    flex: 1,
    backgroundColor: "rgba(20,32,26,.45)",
    justifyContent: "flex-end",
  },
  modal: {
    maxHeight: "90%",
    padding: 18,
    gap: 10,
    backgroundColor: colors.bone,
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
  },
  catalogItem: {
    minHeight: 56,
    paddingVertical: 9,
    borderBottomWidth: 1,
    borderColor: colors.line,
  },
});
