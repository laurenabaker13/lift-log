import { AuthGate } from "@/components/lift-log/auth-gate";
import { AppScreen, LoadingState } from "@/components/lift-log/ui";
import { trpc } from "@/lib/trpc";
import { useRouter } from "expo-router";
import { useEffect, useRef } from "react";
function GuideLauncher() {
  const router = useRouter();
  const utils = trpc.useUtils();
  const reset = trpc.account.resetTips.useMutation();
  const started = useRef(false);
  useEffect(() => {
    if (started.current) return;
    started.current = true;
    reset
      .mutateAsync()
      .then(async () => {
        await utils.settings.get.invalidate();
        router.replace("/workout/new" as never);
      })
      .catch(() => router.replace("/" as never));
  }, [reset, router, utils]);
  return (
    <AppScreen scroll={false}>
      <LoadingState label="Opening tips…" />
    </AppScreen>
  );
}
export default function GuideScreen() {
  return (
    <AuthGate>
      <GuideLauncher />
    </AuthGate>
  );
}
